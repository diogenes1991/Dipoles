#define RANK "6"
*
*	The file with all the declarations for running cOlor traces.
*	The variable RANK tells how many Adjoint invariants of how many
*	non-adjoint invariants can occur simultaneously. For 14 vertices
*	this number is maximally 4 (4 loops in a non-adjoint representation)
*
*	Note: One needs version 3 of FORM to run this.
*	Version 2 (or 2.3) makes no chance. The program would need very
*	extensive reworking and it would become far less efficient.
*	All variables start with the string cOl to avoid potential conflicts
*	with namings in the calling program.
*
*	File by J.Vermaseren, 24-may-1997
*
Symbol cOlNA,cOlNR;
Dimension cOlNA;
AutoDeclare Index cOli,cOlj,cOlk,cOln;
AutoDeclare Symbol cOlI;
AutoDeclare Vector cOlp,cOlq;
AutoDeclare Symbol cOlx,cOly,cOlc;
AutoDeclare Tensor cOld;
AutoDeclare Tensor cOldr(symmetric),cOlda(symmetric);
Vector cOlpR1,...,cOlpR`RANK',cOlpA1,...,cOlpA`RANK';
Tensor cOldR1,...,cOldR`RANK',cOldA1,...,cOldA`RANK';
Tensor,<cOldr1(symmetric)>,...,<cOldr`RANK'(symmetric)>
		,<cOlda1(symmetric)>,...,<cOlda`RANK'(symmetric)>;
Symbol cOln, cOlcA,cOlcR,[cOlcR-cOlcA/2];
Tensor cOlfp,cOlff(cyclic),cOlT,cOlTr(cyclic),cOlTt(cyclic),cOlf3;
NTensor cOlTN,cOlTM;
CFunction cOlTT,cOlnum,cOldddff,cOldff554,cOld,cOldd,cOlddd,cOlorig,cOlacc;
CFunction cOlE,cOlE0,cOlEa,cOlEb,cOlEc,cOldexp;
CFunction cOld33,cOld44,cOld55,cOld433,cOld66,cOld633,cOld543,cOld444,cOld3333
	,cOld77,cOld743,cOld653,cOld644,cOld554,cOld5333,cOld4433a,cOld4433b,cOld4433c
	,cOld88,cOld853,cOld844,cOld763,cOld754,cOld7333,cOld664,cOld655,cOld6433a,cOld6433b,cOld6433c
	,cOld5533a,cOld5533b,cOld5533c,cOld5533d,cOld5443a,cOld5443b,cOld5443c,cOld5443d
	,cOld4444a,cOld4444b,cOld43333a,cOld43333b;
Tensor cOlf(antisymmetric),cOlf1(antisymmetric);
Set cOlpAs:cOlpA1,...,cOlpA`RANK';
Set cOlpRs:cOlpR1,...,cOlpR`RANK';
Set cOlpAR:cOlpA1,...,cOlpA`RANK',cOlpR1,...,cOlpR`RANK';
Set cOldar:cOlda1,...,cOlda`RANK',cOldr1,...,cOldr`RANK';
Set cOldas:cOlda1,...,cOlda`RANK';
Set cOliii:cOli1,...,cOli30;
Set cOljjj:cOlj1,...,cOlj30;
ProperCount ON;
*
*	Next Procedure handles the .sort. This way one can put the program
*	in a checking mode in which there is printing at all .sort instructions
*	by just adding a single statement.
*
#procedure SORT(text)
*Print +f +s;
.sort:`text';
#endprocedure
*
#procedure color
*
*	Main routine for color traces.
*	We need the declarations of the file cfactors.h in the main program.
*	The algorithm is following the paper.
*	We have included some extra reductions for
*	cOlTr( cOli1,cOli2,cOli3,cOli4,...,cOli1,cOli2,cOli3,cOli4,...) and cOlTr( cOli1,cOli2,cOli3,...,cOli1,cOli2,cOli3,...)
*	because that helps very much in some cases.
*
*	If the variable ALTERNATEMETHOD is defined we follow a different
*	order of elimination. This can be useful for deriving identities that
*	are otherwise far from trivial.
*
*	Routine by J.Vermaseren, 24-may-1997
*
#define ik1 "0"
repeat id cOlT(cOli1?,cOli2?,?a)*cOlT(cOli2?,cOli3?,?b) = cOlT(cOli1,cOli3,?a,?b);
id  cOlT(cOli1?,cOli1?,?a) = cOlTr(?a);
*
* We work only with the TR. If there are leftover cOlT we don't
* do anything.
*
if ( count(cOlTr,1) > 0 ) redefine ik1 "1";
#call SORT(color-1)
#ifndef `ALTERNATEMETHOD'
#call adjoint
#endif
#if `ik1' != 0
#do ik1a = 1,1
*
* First try to contract indices. The easy contractions first.
*
repeat;
  id  cOlTr(cOli1?,cOli1?,?a) = cOlcR*cOlTr(?a);
  id  cOlTr(cOli1?,cOli2?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTr(cOli2,?a);
  id  cOlTr(cOli1?,cOli2?,?a)*cOlf(cOli1?,cOli2?,cOli3?) = i_*cOlcA/2*cOlTr(cOli3,?a);
  if ( match(cOlTr(cOli1?,cOli2?,cOli3?,cOli4?,?b,cOli1?,cOli2?,cOli3?,cOli4?,?a)) );
    repeat;
      id  cOlTr(cOli1?,cOli2?,cOli3?,cOli4?,?b,cOli1?,cOli2?,cOli3?,cOli4?,?a) =
         + cOlTr(cOli1,cOli2,cOli3,cOli4,?b,cOli4,cOli3,cOli2,cOli1,?a)
         - 3*cOlTr(cOli1,cOli2,cOli3,?b,cOli3,cOli2,cOli1,?a)*cOlcA
         + 7/4*cOlTr(cOli1,cOli2,?b,cOli2,cOli1,?a)*cOlcA^2
         - 1/12*cOlTr(cOli1,?b,cOli1,?a)*cOlcA^3
         + cOlTr(cOli1,cOli2,?b,cOli3,cOli4,?a)*cOldA(cOli1,cOli2,cOli3,cOli4)
         + 2*cOlTr(cOli1,cOli2,cOli3,?b,cOli3,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOli4,cOlk2)
         + 2*cOlTr(cOli1,cOli2,cOli3,?b,cOli4,cOlk1,cOli1,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli3,cOli4,cOlk2)
         - cOlTr(cOli1,cOli2,cOli3,?b,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOlk2,cOlk3)*cOlf(cOli3,cOli4,cOlk3)*i_
         + cOlTr(cOli1,cOli2,?b,cOli3,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOli3,cOlk3)*cOlf(cOli4,cOlk2,cOlk3)*i_
         - 11/6*cOlTr(cOli1,cOli2,?b,cOli3,cOli4,?a)*cOlf(cOli1,cOli4,cOlk1)*cOlf(cOli2,cOli3,cOlk1)*cOlcA;
      sum cOlk1,cOlk2,cOlk3;
      if ( count(cOldA,1) > 0 );
        #do isbb = 1,`RANK'
          if ( count(cOlpA`isbb',1) == 0 );
              id,once,cOldA(?a) = cOldA`isbb'(?a);
              ToVector,cOldA`isbb',cOlpA`isbb';
          endif;
        #enddo
      endif;
    endrepeat;
  endif;
  if ( match(cOlTr(cOli1?,cOli2?,cOli3?,?b,cOli1?,cOli2?,cOli3?,?a)) );
    repeat;
      id  cOlTr(cOli1?,cOli2?,cOli3?,?b,cOli1?,cOli2?,cOli3?,?a) =
           + 1/4*cOlTr(cOli1,?b,cOli1,?a)*cOlcA^2
           - 3/2*cOlTr(cOli1,cOli2,?b,cOli2,cOli1,?a)*cOlcA
           + cOlTr(cOli1,cOli2,?b,cOli3,cOlk4,?a)*cOlf(cOli1,cOlk4,cOlk5)*cOlf(cOli2,cOli3,cOlk5)
           + cOlTr(cOli1,cOli2,cOli3,?b,cOli3,cOli2,cOli1,?a);
      sum cOlk4,cOlk5;
    endrepeat;
  endif;
  id  cOlTr(cOli1?,cOli2?,?b,cOli1?,cOli2?,?a) = cOlTr(cOli1,cOli2,?b,cOli2,cOli1,?a)
            -cOlcA/2*cOlTr(cOli1,?b,cOli1,?a);
  ReplaceLoop,cOlf,a=3,l<4,outfun=cOlff;
  id  cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
  id  cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
endrepeat;
id  cOlTr = cOlI2R*cOlNA/cOlcR;
*
* Take the trace with the lowest number of different indices
*
id  cOlTr(?a) = cOlTT(?a,cOlTr(?a));
repeat id cOlTT(?a,cOli1?,?b,cOli1?,?c) = cOlTT(?a,?b,?c);
id  cOlTT(?a,cOlx?) = cOlTT(nargs_(?a),cOlx);
repeat;
  id,once,cOlTT(cOlx1?,cOly1?)*cOlTT(cOlx2?,cOly2?) =
    cOlTT(cOlx1,cOly1)*cOly2*theta_(cOlx2-cOlx1)+cOlTT(cOlx2,cOly2)*cOly1*theta_(cOlx1-cOlx2-1);
endrepeat;
id  cOlTT(cOlx?,cOlTr(?a)) = cOlTt(?a);
if ( count(cOlTr,1) > 0 ) redefine ik1a "0";
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-2)
Keep brackets;
#do ik1c = 1,1
repeat;
  repeat;
    repeat;
      repeat;
        id  cOlTt(cOli1?,cOli1?,?a)   = cOlcR*cOlTt(?a);
        id  cOlTt(cOli1?,cOli2?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,?a);
        id  cOlTt(cOli1?,cOli2?,?a)*cOlf(cOli1?,cOli2?,cOli3?) = i_*cOlcA/2*cOlTt(cOli3,?a);
      endrepeat;
      id cOlTt = cOlI2R*cOlNA/cOlcR;
      if ( match(cOlTt(cOli1?,cOli2?,cOli3?,?b,cOli1?,cOli2?,cOli3?,?a)) );
        id  cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,?b,cOli1?,cOli2?,cOli3?,cOli4?,?a) =
           + cOlTt(cOli1,cOli2,cOli3,cOli4,?b,cOli4,cOli3,cOli2,cOli1,?a)
           - 3*cOlTt(cOli1,cOli2,cOli3,?b,cOli3,cOli2,cOli1,?a)*cOlcA
           + 7/4*cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)*cOlcA^2
           - 1/12*cOlTt(cOli1,?b,cOli1,?a)*cOlcA^3
           + cOlTt(cOli1,cOli2,?b,cOli3,cOli4,?a)*cOldA(cOli1,cOli2,cOli3,cOli4)
           + 2*cOlTt(cOli1,cOli2,cOli3,?b,cOli3,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOli4,cOlk2)
           + 2*cOlTt(cOli1,cOli2,cOli3,?b,cOli4,cOlk1,cOli1,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli3,cOli4,cOlk2)
           - cOlTt(cOli1,cOli2,cOli3,?b,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOlk2,cOlk3)*cOlf(cOli3,cOli4,cOlk3)*i_
           + cOlTt(cOli1,cOli2,?b,cOli3,cOli4,cOlk1,?a)*cOlf(cOli1,cOlk1,cOlk2)*cOlf(cOli2,cOli3,cOlk3)*cOlf(cOli4,cOlk2,cOlk3)*i_
           - 11/6*cOlTt(cOli1,cOli2,?b,cOli3,cOli4,?a)*cOlf(cOli1,cOli4,cOlk1)*cOlf(cOli2,cOli3,cOlk1)*cOlcA;
*        sum cOlk1,cOlk2,cOlk3;
        if ( count(cOldA,1) > 0 );
          #do isbb = 1,`RANK'
            if ( count(cOlpA`isbb',1) == 0 );
                id,once,cOldA(?a) = cOldA`isbb'(?a);
                ToVector,cOldA`isbb',cOlpA`isbb';
            endif;
          #enddo
        endif;
        id  cOlTt(cOli1?,cOli2?,cOli3?,?b,cOli1?,cOli2?,cOli3?,?a) =
         + 1/4*cOlTt(cOli1,?b,cOli1,?a)*cOlcA^2
         - 3/2*cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)*cOlcA
         + cOlTt(cOli1,cOli2,?b,cOli3,cOlk4,?a)*cOlf(cOli1,cOlk4,cOlk5)*cOlf(cOli2,cOli3,cOlk5)
         + cOlTt(cOli1,cOli2,cOli3,?b,cOli3,cOli2,cOli1,?a);
        sum cOlk1,...,cOlk5;
      endif;
      id cOlTt(cOli1?,cOli2?,?b,cOli1?,cOli2?,?a) = cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)
        -cOlcA/2*cOlTt(cOli1,?b,cOli1,?a);
      ReplaceLoop,cOlf,a=3,l<4,outfun=cOlff;
      id  cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
      id  cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
    endrepeat;
    id cOlTt(cOli1?,cOli2?,cOli3?,?a)*cOlf(cOli1?,cOli3?,cOli4?) =
        +i_*cOlTt(cOli1,cOlk1,?a)*cOlf(cOli2,cOli3,cOlk1)*cOlf(cOli1,cOli3,cOli4)
        +i_*cOlcA/2*cOlTt(cOli4,cOli2,?a);
    sum cOlk1;
  endrepeat;
  id cOlTt(cOli1?,cOli2?,cOli3?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,?a)
       -cOlTt(cOli1,cOlk2,?a)*cOlf(cOli3,cOli1,cOlk1)*cOlf(cOli2,cOlk1,cOlk2)
       -cOlcA/2*cOlTt(cOli3,cOli2,?a);
  sum cOlk1,cOlk2;
endrepeat;
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-3-1)
Keep Brackets;
repeat;
  repeat;
    repeat;
      repeat;
        repeat;
          repeat;
            id  cOlTt(cOli1?,cOli1?,?a)       = cOlcR*cOlTt(?a);
            id  cOlTt(cOli1?,cOli2?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,?a);
            id  cOlTt(cOli1?,cOli2?,?a)*cOlf(cOli1?,cOli2?,cOli3?) = i_*cOlcA/2*cOlTt(cOli3,?a);
          endrepeat;
          id cOlTt = cOlI2R*cOlNA/cOlcR;
          id cOlTt(cOli1?,cOli2?,?b,cOli1?,cOli2?,?a) = cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)
              -cOlcA/2*cOlTt(cOli1,?b,cOli1,?a);
          ReplaceLoop,cOlf,a=3,l<4,outfun=cOlff;
          id  cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
          id  cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
*          id cOlf(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOli2?,cOli4?) = cOlcA*d_(cOli3,cOli4);
*          id cOlf(cOli1?,cOli2?,cOlj1?)*cOlf(cOli2?,cOli3?,cOlj2?)*cOlf(cOli3?,cOli1?,cOlj3?) = cOlcA/2*cOlf(cOlj1,cOlj2,cOlj3);
        endrepeat;
        id cOlTt(cOli1?,cOli2?,cOli3?,?a)*cOlf(cOli1?,cOli3?,cOli4?) =
            +i_*cOlTt(cOli1,cOlk1,?a)*cOlf(cOli2,cOli3,cOlk1)*cOlf(cOli1,cOli3,cOli4)
            +i_*cOlcA/2*cOlTt(cOli4,cOli2,?a);
        sum cOlk1;
      endrepeat;
      id cOlTt(cOli1?,cOli2?,cOli3?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,?a)
           -cOlTt(cOli1,cOlk2,?a)*cOlf(cOli3,cOli1,cOlk1)*cOlf(cOli2,cOlk1,cOlk2)
           -cOlcA/2*cOlTt(cOli3,cOli2,?a);
      sum cOlk1,cOlk2;
    endrepeat;
    id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,?a)*cOlf(cOli1?,cOli4?,cOli5?) =
        +i_*cOlcA/2*cOlTt(cOli5,cOli2,cOli3,?a)
        +i_*cOlTt(cOli1,cOlk1,cOli3,?a)*cOlf(cOli2,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5)
        +i_*cOlTt(cOli1,cOli2,cOlk1,?a)*cOlf(cOli3,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5);
    sum cOlk1;
  endrepeat;
  id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,?a)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,?a)*cOlf(cOli4,cOli1,cOlk1)
        +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,?a)*cOlf(cOli3,cOli1,cOlk1);
  sum cOlk1;
endrepeat;
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-3-2)
Keep Brackets;
repeat;
  repeat;
    repeat;
      repeat;
        repeat;
          repeat;
            repeat;
              repeat;
                id  cOlTt(cOli1?,cOli1?,?a)   = cOlcR*cOlTt(?a);
                id  cOlTt(cOli1?,cOli2?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,?a);
                id  cOlTt(cOli1?,cOli2?,?a)*cOlf(cOli1?,cOli2?,cOli3?) = i_*cOlcA/2*cOlTt(cOli3,?a);
              endrepeat;
              id cOlTt = cOlI2R*cOlNA/cOlcR;
              id cOlTt(cOli1?,cOli2?,?b,cOli1?,cOli2?,?a) = cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)
                  -cOlcA/2*cOlTt(cOli1,?b,cOli1,?a);
              ReplaceLoop,cOlf,a=3,l<4,outfun=cOlff;
              id  cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
              id  cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
*              id cOlf(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOli2?,cOli4?) = cOlcA*d_(cOli3,cOli4);
*              id cOlf(cOli1?,cOli2?,cOlj1?)*cOlf(cOli2?,cOli3?,cOlj2?)*cOlf(cOli3?,cOli1?,cOlj3?) = cOlcA/2*cOlf(cOlj1,cOlj2,cOlj3);
            endrepeat;
            id cOlTt(cOli1?,cOli2?,cOli3?,?a)*cOlf(cOli1?,cOli3?,cOli4?) =
                +i_*cOlTt(cOli1,cOlk1,?a)*cOlf(cOli2,cOli3,cOlk1)*cOlf(cOli1,cOli3,cOli4)
                +i_*cOlcA/2*cOlTt(cOli4,cOli2,?a);
            sum cOlk1;
          endrepeat;
          id cOlTt(cOli1?,cOli2?,cOli3?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,?a)
               -cOlTt(cOli1,cOlk2,?a)*cOlf(cOli3,cOli1,cOlk1)*cOlf(cOli2,cOlk1,cOlk2)
               -cOlcA/2*cOlTt(cOli3,cOli2,?a);
          sum cOlk1,cOlk2;
        endrepeat;
        id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,?a)*cOlf(cOli1?,cOli4?,cOli5?) =
            +i_*cOlcA/2*cOlTt(cOli5,cOli2,cOli3,?a)
            +i_*cOlTt(cOli1,cOlk1,cOli3,?a)*cOlf(cOli2,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5)
            +i_*cOlTt(cOli1,cOli2,cOlk1,?a)*cOlf(cOli3,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5);
        sum cOlk1;
      endrepeat;
      id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,?a)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,?a)*cOlf(cOli4,cOli1,cOlk1)
            +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,?a)*cOlf(cOli3,cOli1,cOlk1);
      sum cOlk1;
    endrepeat;
    id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,?a)*cOlf(cOli1?,cOli5?,cOli6?) =
        +i_*cOlcA/2*cOlTt(cOli6,cOli2,cOli3,cOli4,?a)
        +i_*cOlTt(cOli1,cOlk1,cOli3,cOli4,?a)*cOlf(cOli2,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6)
        +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,?a)*cOlf(cOli3,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,?a)*cOlf(cOli4,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6);
    sum cOlk1;
  endrepeat;
  id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,cOli5,?a)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk1,?a)*cOlf(cOli5,cOli1,cOlk1)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,cOli5,?a)*cOlf(cOli4,cOli1,cOlk1)
        +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,cOli5,?a)*cOlf(cOli3,cOli1,cOlk1);
  sum cOlk1;
endrepeat;
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-3-3)
Keep Brackets;
repeat;
  repeat;
    repeat;
      repeat;
        repeat;
          repeat;
            repeat;
              repeat;
                repeat;
                  repeat;
                    repeat;
                      repeat;
                        id  cOlTt(cOli1?,cOli1?,?a)   = cOlcR*cOlTt(?a);
                        id  cOlTt(cOli1?,cOli2?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,?a);
                        id  cOlTt(cOli1?,cOli2?,?a)*cOlf(cOli1?,cOli2?,cOli3?) = i_*cOlcA/2*cOlTt(cOli3,?a);
                      endrepeat;
                      id cOlTt = cOlI2R*cOlNA/cOlcR;
                      id cOlTt(cOli1?,cOli2?,?b,cOli1?,cOli2?,?a) = cOlTt(cOli1,cOli2,?b,cOli2,cOli1,?a)
                          -cOlcA/2*cOlTt(cOli1,?b,cOli1,?a);
                      ReplaceLoop,cOlf,a=3,l<4,outfun=cOlff;
                      id  cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
                      id  cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
*                      id cOlf(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOli2?,cOli4?) = cOlcA*d_(cOli3,cOli4);
*                      id cOlf(cOli1?,cOli2?,cOlj1?)*cOlf(cOli2?,cOli3?,cOlj2?)*cOlf(cOli3?,cOli1?,cOlj3?) = cOlcA/2*cOlf(cOlj1,cOlj2,cOlj3);
                    endrepeat;
                    id cOlTt(cOli1?,cOli2?,cOli3?,?a)*cOlf(cOli1?,cOli3?,cOli4?) =
                        +i_*cOlTt(cOli1,cOlk1,?a)*cOlf(cOli2,cOli3,cOlk1)*cOlf(cOli1,cOli3,cOli4)
                        +i_*cOlcA/2*cOlTt(cOli4,cOli2,?a);
                    sum cOlk1;
                  endrepeat;
                  id cOlTt(cOli1?,cOli2?,cOli3?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,?a)
                       -cOlTt(cOli1,cOlk2,?a)*cOlf(cOli3,cOli1,cOlk1)*cOlf(cOli2,cOlk1,cOlk2)
                       -cOlcA/2*cOlTt(cOli3,cOli2,?a);
                  sum cOlk1,cOlk2;
                endrepeat;
                id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,?a)*cOlf(cOli1?,cOli4?,cOli5?) =
                    +i_*cOlcA/2*cOlTt(cOli5,cOli2,cOli3,?a)
                    +i_*cOlTt(cOli1,cOlk1,cOli3,?a)*cOlf(cOli2,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5)
                    +i_*cOlTt(cOli1,cOli2,cOlk1,?a)*cOlf(cOli3,cOli4,cOlk1)*cOlf(cOli1,cOli4,cOli5);
                sum cOlk1;
              endrepeat;
              id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,?a)
                    +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,?a)*cOlf(cOli4,cOli1,cOlk1)
                    +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,?a)*cOlf(cOli3,cOli1,cOlk1);
              sum cOlk1;
            endrepeat;
            id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,?a)*cOlf(cOli1?,cOli5?,cOli6?) =
                +i_*cOlcA/2*cOlTt(cOli6,cOli2,cOli3,cOli4,?a)
                +i_*cOlTt(cOli1,cOlk1,cOli3,cOli4,?a)*cOlf(cOli2,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6)
                +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,?a)*cOlf(cOli3,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6)
                +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,?a)*cOlf(cOli4,cOli5,cOlk1)*cOlf(cOli1,cOli5,cOli6);
            sum cOlk1;
          endrepeat;
          id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,cOli5,?a)
                +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk1,?a)*cOlf(cOli5,cOli1,cOlk1)
                +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,cOli5,?a)*cOlf(cOli4,cOli1,cOlk1)
                +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,cOli5,?a)*cOlf(cOli3,cOli1,cOlk1);
          sum cOlk1;
        endrepeat;
        id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,?a)*cOlf(cOli1?,cOli6?,cOli7?) =
            +i_*cOlcA/2*cOlTt(cOli7,cOli2,cOli3,cOli4,cOli5,?a)
            +i_*cOlTt(cOli1,cOlk1,cOli3,cOli4,cOli5,?a)*cOlf(cOli2,cOli6,cOlk1)*cOlf(cOli1,cOli6,cOli7)
            +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,cOli5,?a)*cOlf(cOli3,cOli6,cOlk1)*cOlf(cOli1,cOli6,cOli7)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,cOli5,?a)*cOlf(cOli4,cOli6,cOlk1)*cOlf(cOli1,cOli6,cOli7)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk1,?a)*cOlf(cOli5,cOli6,cOlk1)*cOlf(cOli1,cOli6,cOli7);
        sum cOlk1;
      endrepeat;
      id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,cOli1?,?a) = [cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,cOli5,cOli6,?a)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOli5,cOlk1,?a)*cOlf(cOli6,cOli1,cOlk1)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk1,cOli6,?a)*cOlf(cOli5,cOli1,cOlk1)
            +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,cOli5,cOli6,?a)*cOlf(cOli4,cOli1,cOlk1)
            +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,cOli5,cOli6,?a)*cOlf(cOli3,cOli1,cOlk1);
      sum cOlk1;
    endrepeat;
    id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,cOli7?,?a)*cOlf(cOli1?,cOli7?,cOli8?) =
        +i_*cOlcA/2*cOlTt(cOli8,cOli2,cOli3,cOli4,cOli5,cOli6,?a)
        +i_*cOlTt(cOli1,cOlk1,cOli3,cOli4,cOli5,cOli6,?a)*cOlf(cOli2,cOli7,cOlk1)*cOlf(cOli1,cOli7,cOli8)
        +i_*cOlTt(cOli1,cOli2,cOlk1,cOli4,cOli5,cOli6,?a)*cOlf(cOli3,cOli7,cOlk1)*cOlf(cOli1,cOli7,cOli8)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOlk1,cOli5,cOli6,?a)*cOlf(cOli4,cOli7,cOlk1)*cOlf(cOli1,cOli7,cOli8)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk1,cOli6,?a)*cOlf(cOli5,cOli7,cOlk1)*cOlf(cOli1,cOli7,cOli8)
        +i_*cOlTt(cOli1,cOli2,cOli3,cOli4,cOli5,cOlk1,?a)*cOlf(cOli6,cOli7,cOlk1)*cOlf(cOli1,cOli7,cOli8);
    sum cOlk1;
  endrepeat;
  id cOlTt(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,cOli7?,cOli1?,?a) =
        +[cOlcR-cOlcA/2]*cOlTt(cOli2,cOli3,cOli4,cOli5,cOli6,cOli7,?a)
        -cOlTt(cOli1,cOli2,cOli3,cOli4,cOli5,cOlk2,?a)*cOlf(cOli6,cOlk1,cOlk2)*cOlf(cOli7,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk2,cOli6,?a)*cOlf(cOli5,cOlk1,cOlk2)*cOlf(cOli7,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOli3,cOli4,cOlk2,cOli7,?a)*cOlf(cOli5,cOlk1,cOlk2)*cOlf(cOli6,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOli3,cOlk2,cOli5,cOli6,?a)*cOlf(cOli4,cOlk1,cOlk2)*cOlf(cOli7,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOli3,cOlk2,cOli5,cOli7,?a)*cOlf(cOli4,cOlk1,cOlk2)*cOlf(cOli6,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOli3,cOlk2,cOli6,cOli7,?a)*cOlf(cOli4,cOlk1,cOlk2)*cOlf(cOli5,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOlk2,cOli4,cOli5,cOli6,?a)*cOlf(cOli3,cOlk1,cOlk2)*cOlf(cOli7,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOlk2,cOli4,cOli5,cOli7,?a)*cOlf(cOli3,cOlk1,cOlk2)*cOlf(cOli6,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOlk2,cOli4,cOli6,cOli7,?a)*cOlf(cOli3,cOlk1,cOlk2)*cOlf(cOli5,cOli1,cOlk1)
        -cOlTt(cOli1,cOli2,cOlk2,cOli5,cOli6,cOli7,?a)*cOlf(cOli3,cOlk1,cOlk2)*cOlf(cOli4,cOli1,cOlk1)
        -cOlTt(cOli1,cOlk2,cOli3,cOli4,cOli5,cOli6,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli7,cOli1,cOlk1)
        -cOlTt(cOli1,cOlk2,cOli3,cOli4,cOli5,cOli7,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli6,cOli1,cOlk1)
        -cOlTt(cOli1,cOlk2,cOli3,cOli4,cOli6,cOli7,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli5,cOli1,cOlk1)
        -cOlTt(cOli1,cOlk2,cOli3,cOli5,cOli6,cOli7,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli4,cOli1,cOlk1)
        -cOlTt(cOli1,cOlk2,cOli4,cOli5,cOli6,cOli7,?a)*cOlf(cOli2,cOlk1,cOlk2)*cOlf(cOli3,cOli1,cOlk1)
        -cOlcA/2*cOlTt(cOli7,cOli2,cOli3,cOli4,cOli5,cOli6,?a)
        -cOlcA/2*cOlTt(cOli6,cOli2,cOli3,cOli4,cOli5,cOli7,?a)
        -cOlcA/2*cOlTt(cOli5,cOli2,cOli3,cOli4,cOli6,cOli7,?a)
        -cOlcA/2*cOlTt(cOli4,cOli2,cOli3,cOli5,cOli6,cOli7,?a)
        -cOlcA/2*cOlTt(cOli3,cOli2,cOli4,cOli5,cOli6,cOli7,?a);
  sum cOlk1,cOlk2;
endrepeat;
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-3-4)
#ifndef `ALTERNATEMETHOD'
Keep brackets;
repeat;
	if ( count(cOlff,1) == 0 );
		ReplaceLoop,cOlf,a=3,l=all,outfun=cOlff;
		id	cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
		id	cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
	endif;
endrepeat;
if ( count(cOlff,1) ) redefine ik1c "0";
#call adjoint
#endif
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-4)
Keep Brackets;
#enddo
*
*   Now we eliminate the Trace cOlTt. It has only different indices now!
*   There is still a possible simplification in this algorithm when
*   there is already a cOldR which is symmetric. If it has more than one
*   index common with our cOlTt, there could be shortcuts.
*   These are exploited by writing cOldR(cOli1,...,in) = cOlpR(cOli1)*...*cOlpR(in)
*   The vector has an extra index to keep the different cOldR apart.
*
id  cOlTt(cOli1?) = 0;
id  cOlTt(cOli1?,cOli2?) = cOlI2R*d_(cOli1,cOli2);
id  cOlTt(cOli1?,cOli2?,cOli3?) = cOldR(cOli1,cOli2,cOli3)+i_/2*cOlf(cOli1,cOli2,cOli3)*cOlI2R;
id  cOlTt(cOli1?,cOli2?,cOli3?,cOli4?) = cOldR(cOli1,cOli2,cOli3,cOli4)
    +1/2*i_*(cOldR(cOli1,cOli2,cOlk)*cOlf(cOli3,cOli4,cOlk)+cOldR(cOli3,cOli4,cOlk)*cOlf(cOli1,cOli2,cOlk))
    -1/6*cOlf(cOli1,cOli3,cOlk)*cOlf(cOli2,cOli4,cOlk)*cOlI2R+1/3*cOlf(cOli1,cOli4,cOlk)*cOlf(cOli2,cOli3,cOlk)*cOlI2R;

id  cOlTt(?a) = cOlT(?a);
id  cOlT(cOli1?,cOli2?,?a) = cOlE0(cOli1,cOli2)*cOlT(?a)+cOlE0(cOlk)*i_*cOlf(cOli1,cOli2,cOlk)*cOlT(?a)/2;
sum cOlk;
repeat;
id  cOlE0(?a)*cOlT(cOli1?,?b) = cOlE0(?a,cOli1)*cOlT(?b)
        +sum_(cOlx,1,nargs_(?a),Bernoulli_(cOlx)*cOlE(cOlx,?a,cOli1))*cOlT(?b);
repeat;
    id  cOlE(cOlx?pos_,?a,cOli1?) = distrib_(1,1,cOlEa,cOlEb,?a)*cOlEc(cOlx-1,cOli1,cOlk);
    id  cOlEa(cOli1?)*cOlEb(?a)*cOlEc(cOlx?,cOli2?,cOli3?) = cOlE(cOlx,?a,cOli3)*i_*cOlf(cOli1,cOli2,cOli3);
    sum cOlk;
endrepeat;
id  cOlE(0,?a) = cOlE0(?a);
id  cOlT = 1;
if ( match(cOlT(cOli1?)) );
    id  cOlE0(?a)*cOlT(cOli1?) = cOldR(?a,cOli1);
elseif ( match(cOlT(cOli1?,cOli2?)) );
    id  cOlE0(cOli1?)*cOlT(cOli2?,cOli3?) = cOldR(cOli1,cOli2,cOli3)+i_/2*cOlf(cOli1,cOli2,cOli3)*cOlI2R;
    id  cOlE0(cOli1?,cOli2?)*cOlT(cOli3?,cOli4?) = cOldR(cOli1,cOli2,cOli3,cOli4)
        +i_/2*cOlf(cOli3,cOli4,cOlk)*cOldR(cOli1,cOli2,cOlk)
        +cOlI2R*(cOlf(cOli1,cOli3,cOlk)*cOlf(cOli2,cOli4,cOlk)+cOlf(cOli1,cOli4,cOlk)*cOlf(cOli2,cOli3,cOlk))/12;
    sum cOlk;
endif;
endrepeat;
id  cOldR(cOli1?) = 0;
id  cOldR(cOli1?,cOli2?) = cOlI2R*d_(cOli1,cOli2);
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-5)
Keep Brackets;
if ( count(cOldR,1) );
#do ik1d = 1,`RANK'
    if ( count(cOlpR`ik1d',1) == 0 );
        id,once,cOldR(?a) = cOldR`ik1d'(?a);
        ToVector,cOldR`ik1d',cOlpR`ik1d';
    endif;
#enddo
endif;
AB	cOlcR,cOlcA,[cOlcR-cOlcA/2];
#call SORT(color-6)
Repeat;
    ReplaceLoop,cOlf,argument=3,loopsize<4,outfun=cOlff;
    id cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
    id cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
EndRepeat;
#do isimpli = 1,`RANK'
    if ( count(cOlpR`isimpli',1) == 3 )
        id cOlf(cOlpR`isimpli',cOli1?,cOli3?)*cOlf(cOlpR`isimpli',cOli2?,cOli3?) =
            cOlpR`isimpli'(cOli1)*cOlpR`isimpli'(cOli2)*cOlcA/2;
#enddo
#enddo
*
* At this point we have eliminated the R-traces. We are left with the
* traces in the adjoint representation.
*
#endif
id	[cOlcR-cOlcA/2] = cOlcR-cOlcA/2;
#endprocedure
*
#procedure adjoint
*
*	Procedure to deal with gluonic loops (adjoint representation)
*	In this case there are special shortcuts for odd loops.
*	Also even loops have special savings.
*	Use the declarations of the file cfactor.h
*	Do not use indices cOlk,cOlk1,cOlk2,cOlk3,cOlk4,cOlk5 when calling this routine!
*
*	Routine by J.Vermaseren 24-may-1997
*
#define adj "0"
repeat;
	if ( count(cOlff,1) == 0 );
		ReplaceLoop,cOlf,a=3,l=all,outfun=cOlff;
		id	cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
		id	cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
	endif;
endrepeat;
if ( count(cOlff,1) ) redefine adj "1";
renumber;
#call SORT(adjoint-1)
#if `adj' > 0
#do iStageB = 1,1
	id,once,cOlff(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,cOli7?) = 1/2*(
		+cOlff(cOlk1,cOli6,cOli5,cOli4,cOli3,cOli2)*cOlf(cOli1,cOli7,cOlk1)
		+cOlff(cOlk1,cOli5,cOli4,cOli3,cOli2,cOli7)*cOlf(cOli1,cOli6,cOlk1)
		+cOlff(cOli1,cOli5,cOli4,cOli3,cOli2,cOlk1)*cOlf(cOli7,cOli6,cOlk1)
		+cOlff(cOli1,cOlk1,cOli3,cOli2,cOli6,cOli7)*cOlf(cOli5,cOli4,cOlk1)
		+cOlff(cOli1,cOli4,cOlk1,cOli2,cOli6,cOli7)*cOlf(cOli5,cOli3,cOlk1)
		+cOlff(cOli1,cOli4,cOli3,cOlk1,cOli6,cOli7)*cOlf(cOli5,cOli2,cOlk1)
		+cOlff(cOli1,cOlk1,cOli2,cOli5,cOli6,cOli7)*cOlf(cOli4,cOli3,cOlk1)
		+cOlff(cOli1,cOli3,cOlk1,cOli5,cOli6,cOli7)*cOlf(cOli4,cOli2,cOlk1)
		+cOlff(cOli1,cOlk1,cOli4,cOli5,cOli6,cOli7)*cOlf(cOli3,cOli2,cOlk1)
	);
#call SORT(adjoint-2-a)
	id,once,cOlff(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?) = -cOldA(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)
       - 1/20*cOlff(cOli1,cOli2,cOli3,cOli4,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli2,cOli3,cOli5,cOlk2)*cOlf(cOli4,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli3,cOlk2,cOli4)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli3,cOlk2,cOli5)*cOlf(cOli4,cOli6,cOlk2)
       - 1/3*cOlff(cOli1,cOli2,cOli3,cOlk2,cOli6)*cOlf(cOli4,cOli5,cOlk2)
       - 1/20*cOlff(cOli1,cOli2,cOli4,cOli3,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli2,cOli4,cOli5,cOlk2)*cOlf(cOli3,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli4,cOlk2,cOli3)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli4,cOlk2,cOli5)*cOlf(cOli3,cOli6,cOlk2)
       - 7/30*cOlff(cOli1,cOli2,cOli4,cOlk2,cOli6)*cOlf(cOli3,cOli5,cOlk2)
       - 1/20*cOlff(cOli1,cOli2,cOli5,cOli3,cOlk2)*cOlf(cOli4,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli2,cOli5,cOli4,cOlk2)*cOlf(cOli3,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli5,cOlk2,cOli3)*cOlf(cOli4,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli2,cOli5,cOlk2,cOli4)*cOlf(cOli3,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli3,cOli4)*cOlf(cOli5,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli3,cOli5)*cOlf(cOli4,cOli6,cOlk2)
       - 7/60*cOlff(cOli1,cOli2,cOlk2,cOli3,cOli6)*cOlf(cOli4,cOli5,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli4,cOli3)*cOlf(cOli5,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli4,cOli5)*cOlf(cOli3,cOli6,cOlk2)
       - 7/60*cOlff(cOli1,cOli2,cOlk2,cOli4,cOli6)*cOlf(cOli3,cOli5,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli5,cOli3)*cOlf(cOli4,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli2,cOlk2,cOli5,cOli4)*cOlf(cOli3,cOli6,cOlk2)
       - 9/20*cOlff(cOli1,cOli2,cOlk2,cOli5,cOli6)*cOlf(cOli3,cOli4,cOlk2)
       - 1/20*cOlff(cOli1,cOli3,cOli2,cOli4,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli3,cOli2,cOli5,cOlk2)*cOlf(cOli4,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli3,cOli2,cOlk2,cOli4)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli3,cOli2,cOlk2,cOli5)*cOlf(cOli4,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli3,cOli4,cOli2,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli3,cOli4,cOlk2,cOli5)*cOlf(cOli2,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOli4,cOlk2,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 1/20*cOlff(cOli1,cOli3,cOli5,cOli2,cOlk2)*cOlf(cOli4,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli3,cOli5,cOlk2,cOli4)*cOlf(cOli2,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOli5,cOlk2,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOlk2,cOli2,cOli4)*cOlf(cOli5,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOlk2,cOli2,cOli5)*cOlf(cOli4,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOlk2,cOli4,cOli5)*cOlf(cOli2,cOli6,cOlk2)
       - 1/12*cOlff(cOli1,cOli3,cOlk2,cOli4,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 1/60*cOlff(cOli1,cOli3,cOlk2,cOli5,cOli4)*cOlf(cOli2,cOli6,cOlk2)
       - 1/12*cOlff(cOli1,cOli3,cOlk2,cOli5,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 1/20*cOlff(cOli1,cOli4,cOli2,cOli3,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli4,cOli2,cOlk2,cOli5)*cOlf(cOli3,cOli6,cOlk2)
       - 1/20*cOlff(cOli1,cOli4,cOli3,cOli2,cOlk2)*cOlf(cOli5,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli4,cOli3,cOlk2,cOli5)*cOlf(cOli2,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli4,cOli3,cOlk2,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 1/60*cOlff(cOli1,cOli4,cOli5,cOlk2,cOli6)*cOlf(cOli2,cOli3,cOlk2)
       - 1/60*cOlff(cOli1,cOli4,cOlk2,cOli2,cOli5)*cOlf(cOli3,cOli6,cOlk2)
       - 1/60*cOlff(cOli1,cOli4,cOlk2,cOli3,cOli5)*cOlf(cOli2,cOli6,cOlk2)
       - 1/30*cOlff(cOli1,cOli4,cOlk2,cOli3,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 1/12*cOlff(cOli1,cOli4,cOlk2,cOli5,cOli6)*cOlf(cOli2,cOli3,cOlk2)
       - 1/60*cOlff(cOli1,cOli5,cOli3,cOlk2,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 1/60*cOlff(cOli1,cOli5,cOli4,cOlk2,cOli6)*cOlf(cOli2,cOli3,cOlk2)
       - 1/30*cOlff(cOli1,cOli5,cOlk2,cOli3,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 1/30*cOlff(cOli1,cOli5,cOlk2,cOli4,cOli6)*cOlf(cOli2,cOli3,cOlk2)
       - 1/20*cOlff(cOli1,cOlk2,cOli3,cOli4,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 3/20*cOlff(cOli1,cOlk2,cOli3,cOli5,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 1/20*cOlff(cOli1,cOlk2,cOli4,cOli3,cOli6)*cOlf(cOli2,cOli5,cOlk2)
       - 3/20*cOlff(cOli1,cOlk2,cOli4,cOli5,cOli6)*cOlf(cOli2,cOli3,cOlk2)
       - 1/20*cOlff(cOli1,cOlk2,cOli5,cOli3,cOli6)*cOlf(cOli2,cOli4,cOlk2)
       - 3/20*cOlff(cOli1,cOlk2,cOli5,cOli4,cOli6)*cOlf(cOli2,cOli3,cOlk2);
#call SORT(adjoint-2-b)
id,once,cOlff(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?) = 
		+1/2*cOldA(cOli2,cOli3,cOli4,cOlk3)*cOlf(cOlk3,cOli1,cOli5)
		-1/2*cOldA(cOli1,cOli4,cOli5,cOlk3)*cOlf(cOlk3,cOli2,cOli3)
		-1/2*cOldA(cOli1,cOli3,cOli5,cOlk3)*cOlf(cOlk3,cOli2,cOli4)
		-1/2*cOldA(cOli1,cOli2,cOli5,cOlk3)*cOlf(cOlk3,cOli3,cOli4)
       + 1/12*cOlf(cOli1,cOlk3,cOlk4)*cOlf(cOli2,cOli3,cOlk3)*cOlf(cOli4,cOli5,cOlk4)*cOlcA
       + 1/12*cOlf(cOli1,cOlk3,cOlk4)*cOlf(cOli2,cOli5,cOlk4)*cOlf(cOli3,cOli4,cOlk3)*cOlcA
       + 1/12*cOlf(cOli1,cOli3,cOlk3)*cOlf(cOli2,cOli4,cOlk4)*cOlf(cOli5,cOlk3,cOlk4)*cOlcA
       - 1/6*cOlf(cOli1,cOli5,cOlk3)*cOlf(cOli2,cOli3,cOlk4)*cOlf(cOli4,cOlk3,cOlk4)*cOlcA
       + 1/12*cOlf(cOli1,cOli5,cOlk3)*cOlf(cOli2,cOli4,cOlk4)*cOlf(cOli3,cOlk3,cOlk4)*cOlcA;
id,once,cOlff(cOli1?,cOli2?,cOli3?,cOli4?) = cOldA(cOli1,cOli2,cOli3,cOli4)
		+cOlcA*cOlf(cOli1,cOli2,cOlk5)*cOlf(cOli4,cOli3,cOlk5)/6
		+cOlcA*cOlf(cOli1,cOlk5,cOli4)*cOlf(cOli3,cOli2,cOlk5)/6;
sum cOlk1,cOlk2,cOlk3,cOlk4,cOlk5;
if ( count(cOlff,1) );
	id  cOlff(?a) = cOlT(?a);
	id  cOlT(cOli1?,cOli2?,?a) = -cOlE0(cOli1,cOli2)*cOlT(?a)-cOlE0(cOlk)*i_*cOlf(cOli1,cOli2,cOlk)*cOlT(?a)/2;
	sum cOlk;
	repeat;
	id  cOlE0(?a)*cOlT(cOli1?,?b) = i_*cOlE0(?a,cOli1)*cOlT(?b)
        +i_*sum_(cOlx,1,nargs_(?a),Bernoulli_(cOlx)*cOlE(cOlx,?a,cOli1))*cOlT(?b);
	repeat;
    	id  cOlE(cOlx?pos_,?a,cOli1?) = distrib_(1,1,cOlEa,cOlEb,?a)*cOlEc(cOlx-1,cOli1,cOlk);
	    id  cOlEa(cOli1?)*cOlEb(?a)*cOlEc(cOlx?,cOli2?,cOli3?) = cOlE(cOlx,?a,cOli3)*i_*cOlf(cOli1,cOli2,cOli3);
    	sum cOlk;
	endrepeat;
	id  cOlE(0,?a) = cOlE0(?a);
	id  cOlT = 1;
	if ( match(cOlT(cOli1?)) );
    	id  cOlE0(?a)*cOlT(cOli1?) = i_*cOldA(?a,cOli1)*cOlacc(1-sign_(nargs_(?a)))/2;
		id	cOlacc(cOlx?) = cOlx;
	elseif ( match(cOlT(cOli1?,cOli2?)) );
    	id  cOlE0(cOli1?)*cOlT(cOli2?,cOli3?) = -i_*cOlcA/2*cOlf(cOli1,cOli2,cOli3);
	    id  cOlE0(cOli1?,cOli2?)*cOlT(cOli3?,cOli4?) = -cOldA(cOli1,cOli2,cOli3,cOli4)
    	    -cOlcA*(cOlf(cOli1,cOli3,cOlk)*cOlf(cOli2,cOli4,cOlk)+cOlf(cOli1,cOli4,cOlk)*cOlf(cOli2,cOli3,cOlk))/12;
	    sum cOlk;
	endif;
	endrepeat;
	id  cOldA(cOli1?) = 0;
	id  cOldA(cOli1?,cOli2?) = cOlcA*d_(cOli1,cOli2);
endif;
#call SORT(adjoint-3)
if ( count(cOldA,1) > 0 );
#do isbb = 1,`RANK'
	if ( count(cOlpA`isbb',1) == 0 );
		id,once,cOldA(?a) = cOldA`isbb'(?a);
		ToVector,cOldA`isbb',cOlpA`isbb';
	endif;
#enddo
endif;
repeat;
	if ( count(cOlff,1) == 0 );
		ReplaceLoop,cOlf,a=3,l=all,outfun=cOlff;
		id	cOlff(cOli1?,cOli2?) = -cOlcA*d_(cOli1,cOli2);
		id	cOlff(cOli1?,cOli2?,cOli3?) = cOlcA/2*cOlf(cOli1,cOli2,cOli3);
	endif;
endrepeat;
if ( count(cOlff,1) ) redefine iStageB "0";
#call SORT(adjoint-4)
#enddo
#endif
#endprocedure
*
#procedure simpli
*
*	Procedure tries to eliminate cOlf tensors in an environment of invariants.
*	The strategy is:
*	Look for d1(cOli1,cOli2,...)*d2(cOli1,cOli3,...)*cOlf(cOli1,cOli2,cOli3)
*	Take the two d1,d2 with the largest number of common indices.
*	Apply the generalized Jacobi identity for the d that has most
*	indices contracted with an cOlf.
*	If such a construction is not present, try with common indices.
*	Take the d with the largest number of contractions with an cOlf.
*	We do everything twice because the second time we choose in case
*	of a tie the other d.
*	Thus far it reduces everything up to 14 vertices and the majority
*	of terms with 16 vertices.
*
*	Made by J.Vermaseren, 24-may-1997
*
if ( count(cOlf,1) != multipleof(2) ) discard;
#call contract
#call SORT(simpli-0)
#do isimpli = 1,`RANK'
	if ( count(cOlpR`isimpli',1) == 3 )
		id cOlf(cOlpR`isimpli',cOli1?,cOli3?)*cOlf(cOlpR`isimpli',cOli2?,cOli3?) =
			cOlpR`isimpli'(cOli1)*cOlpR`isimpli'(cOli2)*cOlcA/2;
#enddo
#call d2f1

#call makeds
#define ftodo "0"
if ( count(cOlf,1) ) redefine ftodo "1";
#call SORT(simpli-1)

#if `ftodo' > 0
#do ireduce = 1,6
#call dddff
renumber;
#call SORT(simpli-`ireduce'-1)
#do j = 1,2
if ( match(cOlf(cOlp1?,cOlp2?,cOli1?)*cOlp1?.cOlp2?) );
	repeat id,once,cOlf(cOlp1?,cOlp2?,cOli1?)*cOlp1?.cOlp2?^cOlx?pos_ = cOlf(cOlp1,cOlp2,cOli1)*cOldd(cOlp1,cOlp2,cOlx);
	id	cOldd(cOlp1?,cOlp2?,1) = cOldd(cOlp1,cOlp2);
	if ( match(cOldd(cOlp1?,cOlp2?,cOlx?)) );
		id	cOldd(cOlp1?,cOlp2?) = cOldd(cOlp1,cOlp2,1);
		repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp3?,cOlp4?,cOlx2?) =
			+theta_(cOlx1-cOlx2)*cOldd(cOlp1,cOlp2,cOlx1)*cOlp3.cOlp4^cOlx2
			+theta_(cOlx2-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx2)*cOlp1.cOlp2^cOlx1;
	else;
		repeat;
			id,once,cOldd(cOlp1?,cOlp2?) = cOlddd(cOlp1,cOlp2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp1,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx1*cOlf(cOlp1,cOli1,cOli2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp2?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp2,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx2*cOlf(cOlp1,cOli1,cOli2);
			id	cOlddd(cOlp1?,cOlp2?)*cOlx1^cOly1?*cOlx2^cOly2? = cOldd(cOlp1,cOlp2,cOly1,cOly2);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = theta_(cOlx1-cOlx2)*cOldd(cOlp1,cOlp2,cOlx1,cOlx1+cOlx2)
				+theta_(cOlx2-cOlx1-1)*cOldd(cOlp2,cOlp1,cOlx2,cOlx1+cOlx2);
		repeat;
			id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?)*cOldd(cOlp3?,cOlp4?,cOlx3?,cOlx4?) =
				+theta_(cOlx1-cOlx3-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)*cOlp3.cOlp4
				+theta_(cOlx3-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)*cOlp1.cOlp2
				+delta_(cOlx1-cOlx3)*theta_(cOlx2-cOlx4)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)*cOlp3.cOlp4
				+delta_(cOlx1-cOlx3)*theta_(cOlx4-cOlx2-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)*cOlp1.cOlp2;
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = cOldd(cOlp1,cOlp2,1);
	endif;
	repeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx?)*cOlp1?.cOlp3? = cOldd(cOlp1,cOlp2,cOlx)*cOldA1(cOlp3);
		id	cOldd(cOlp1?,cOlp2?,cOlx?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOldd(cOlp1,cOlp2,cOlx)*cOldA1(cOlk)*cOlf(cOlk,cOli1,cOli2);
		sum cOlk;
	endrepeat;
	repeat id cOldA1(?a)*cOldA1(?b) = cOldA1(?a,?b);
	id	cOldA1(?a) = cOlda1(?a);
	id	cOlda1(cOli1?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) = 0;
	id	cOlda1(cOli1?,cOli2?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5,cOli6)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2,cOli6)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOli5,cOlp2)*cOlf(cOli1,cOli6,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	Multiply replace_(cOlda1,cOldA1);
	repeat id cOldA1(cOli1?,cOli2?,?a)*cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1(cOli1)*cOldA1(cOli2,?a)*cOldd(cOlp1,cOlp2,cOlx);
	id	cOldA1(cOli1?)*cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1(cOli1)*cOldd(cOlp1,cOlp2,cOlx);
	id	cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1.cOlp2^cOlx;
else if ( match(cOlf(cOlp1?,cOlp2?,cOli1?)) );
	id	cOlf(cOlp1?,cOlp2?,cOli1?) = cOlf(cOlp1,cOlp2,cOli1)*cOldd(cOlp1,cOlp2,1);
	repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp1?,cOlp2?,cOlx2?) = cOldd(cOlp1,cOlp2,cOlx1+cOlx2);
	id	cOldd(cOlp1?,cOlp2?,1) = cOldd(cOlp1,cOlp2);
	if ( match(cOldd(cOlp1?,cOlp2?,cOlx?)) );
		id	cOldd(cOlp1?,cOlp2?) = cOldd(cOlp1,cOlp2,1);
		repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp3?,cOlp4?,cOlx2?) =
				+theta_(cOlx1-cOlx2)*cOldd(cOlp1,cOlp2,cOlx1)
				+theta_(cOlx2-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx2);
		id	cOldd(cOlp1?,cOlp2?,cOlx?) = cOldd(cOlp1,cOlp2);
	else;
		repeat;
			id,once,cOldd(cOlp1?,cOlp2?) = cOlddd(cOlp1,cOlp2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp1,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx1*cOlf(cOlp1,cOli1,cOli2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp2?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp2,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx2*cOlf(cOlp1,cOli1,cOli2);
			id	cOlddd(cOlp1?,cOlp2?)*cOlx1^cOly1?*cOlx2^cOly2? = cOldd(cOlp1,cOlp2,cOly1,cOly2);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = theta_(cOlx1-cOlx2)*cOldd(cOlp1,cOlp2,cOlx1,cOlx1+cOlx2)
				+theta_(cOlx2-cOlx1-1)*cOldd(cOlp2,cOlp1,cOlx2,cOlx1+cOlx2);
		repeat;
			id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?)*cOldd(cOlp3?,cOlp4?,cOlx3?,cOlx4?) =
				+theta_(cOlx1-cOlx3-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)
				+theta_(cOlx3-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)
				+delta_(cOlx1-cOlx3)*theta_(cOlx2-cOlx4)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)
				+delta_(cOlx1-cOlx3)*theta_(cOlx4-cOlx2-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = cOldd(cOlp1,cOlp2);
	endif;
	repeat;
		id	cOldd(cOlp1?,cOlp2?)*cOlp1?.cOlp3? = cOldd(cOlp1,cOlp2)*cOldA1(cOlp3);
		id	cOldd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOldd(cOlp1,cOlp2)*cOldA1(cOlk)*cOlf(cOlk,cOli1,cOli2);
		sum cOlk;
	endrepeat;
	repeat id cOldA1(?a)*cOldA1(?b) = cOldA1(?a,?b);
	id	cOldA1(?a) = cOlda1(?a);
	id	cOlda1(cOli1?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) = 0;
	id	cOlda1(cOli1?,cOli2?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5,cOli6)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2,cOli6)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOli5,cOlp2)*cOlf(cOli1,cOli6,cOlj1)*cOldd(cOlp1,cOlp2);
	Multiply replace_(cOlda1,cOldA1);
	repeat id cOldA1(cOli1?,cOli2?,?a)*cOldd(cOlp1?,cOlp2?) = cOlp1(cOli1)*cOldA1(cOli2,?a)*cOldd(cOlp1,cOlp2);
	id	cOldA1(cOli1?)*cOldd(cOlp1?,cOlp2?) = cOlp1(cOli1)*cOldd(cOlp1,cOlp2);
	id	cOldd(cOlp1?,cOlp2?) = 1;
endif;
#call adjoint
#call dddff
#call d2f1
#call makeds
TryReplace,cOlpA1,cOlpA2,cOlpA2,cOlpA1;
TryReplace,cOlpA1,cOlpA3,cOlpA3,cOlpA1;
TryReplace,cOlpA1,cOlpA4,cOlpA4,cOlpA1;
TryReplace,cOlpA2,cOlpA3,cOlpA3,cOlpA2;
TryReplace,cOlpA2,cOlpA4,cOlpA4,cOlpA2;
TryReplace,cOlpA3,cOlpA4,cOlpA4,cOlpA3;
Renumber 1;
#call SORT(simpli-`ireduce'-2)
#enddo
if ( match(cOlf(cOlp1?,cOlp2?,cOli1?)*cOlp1?.cOlp2?) );
	repeat id	cOlf(cOlp1?,cOlp2?,cOli1?)*cOlp1?.cOlp2?^cOlx?pos_ = cOlf(cOlp1,cOlp2,cOli1)*cOldd(cOlp2,cOlp1,cOlx);
	id	cOldd(cOlp1?,cOlp2?,1) = cOldd(cOlp1,cOlp2);
	if ( match(cOldd(cOlp1?,cOlp2?,cOlx?)) );
		id	cOldd(cOlp1?,cOlp2?) = cOldd(cOlp1,cOlp2,1);
		repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp3?,cOlp4?,cOlx2?) =
			+theta_(cOlx1-cOlx2)*cOldd(cOlp1,cOlp2,cOlx1)*cOlp3.cOlp4^cOlx2
			+theta_(cOlx2-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx2)*cOlp1.cOlp2^cOlx1;
	else;
		repeat;
			id,once,cOldd(cOlp1?,cOlp2?) = cOlddd(cOlp1,cOlp2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp1,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx1*cOlf(cOlp1,cOli1,cOli2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp2?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp2,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx2*cOlf(cOlp1,cOli1,cOli2);
			id	cOlddd(cOlp1?,cOlp2?)*cOlx1^cOly1?*cOlx2^cOly2? = cOldd(cOlp1,cOlp2,cOly1,cOly2);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = theta_(cOlx1-cOlx2-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx1+cOlx2)
				+theta_(cOlx2-cOlx1)*cOldd(cOlp2,cOlp1,cOlx2,cOlx1+cOlx2);
		repeat;
			id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?)*cOldd(cOlp3?,cOlp4?,cOlx3?,cOlx4?) =
				+theta_(cOlx1-cOlx3-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)*cOlp3.cOlp4
				+theta_(cOlx3-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)*cOlp1.cOlp2
				+delta_(cOlx1-cOlx3)*theta_(cOlx2-cOlx4-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)*cOlp3.cOlp4
				+delta_(cOlx1-cOlx3)*theta_(cOlx4-cOlx2)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)*cOlp1.cOlp2;
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = cOldd(cOlp1,cOlp2,1);
	endif;
	repeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx?)*cOlp1?.cOlp3? = cOldd(cOlp1,cOlp2,cOlx)*cOldA1(cOlp3);
		id	cOldd(cOlp1?,cOlp2?,cOlx?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOldd(cOlp1,cOlp2,cOlx)*cOldA1(cOlk)*cOlf(cOlk,cOli1,cOli2);
		sum cOlk;
	endrepeat;
	repeat id cOldA1(?a)*cOldA1(?b) = cOldA1(?a,?b);
	id	cOldA1(?a) = cOlda1(?a);
	id	cOlda1(cOli1?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) = 0;
	id	cOlda1(cOli1?,cOli2?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?,cOlx?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5,cOli6)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2,cOli6)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOli5,cOlp2)*cOlf(cOli1,cOli6,cOlj1)*cOldd(cOlp1,cOlp2,cOlx)/(cOlx+1);
	Multiply replace_(cOlda1,cOldA1);
	repeat id cOldA1(cOli1?,cOli2?,?a)*cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1(cOli1)*cOldA1(cOli2,?a)*cOldd(cOlp1,cOlp2,cOlx);
	id	cOldA1(cOli1?)*cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1(cOli1)*cOldd(cOlp1,cOlp2,cOlx);
	id	cOldd(cOlp1?,cOlp2?,cOlx?) = cOlp1.cOlp2^cOlx;
else if ( match(cOlf(cOlp1?,cOlp2?,cOli1?)) );
	id	cOlf(cOlp1?,cOlp2?,cOli1?) = cOlf(cOlp1,cOlp2,cOli1)*cOldd(cOlp2,cOlp1,1);
	repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp1?,cOlp2?,cOlx2?) = cOldd(cOlp1,cOlp2,cOlx1+cOlx2);
	if ( match(cOldd(cOlp1?,cOlp2?,cOlx?)) );
		id	cOldd(cOlp1?,cOlp2?) = cOldd(cOlp1,cOlp2,1);
		repeat id	cOldd(cOlp1?,cOlp2?,cOlx1?)*cOldd(cOlp3?,cOlp4?,cOlx2?) =
				+theta_(cOlx2-cOlx1)*cOldd(cOlp1,cOlp2,cOlx1)
				+theta_(cOlx1-cOlx2-1)*cOldd(cOlp3,cOlp4,cOlx2);
		id	cOldd(cOlp1?,cOlp2?,cOlx?) = cOldd(cOlp1,cOlp2);
	else;
		repeat;
			id,once,cOldd(cOlp1?,cOlp2?) = cOlddd(cOlp1,cOlp2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp1,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx1*cOlf(cOlp1,cOli1,cOli2);
			repeat id	cOlddd(cOlp1?,cOlp2?)*cOlf(cOlp2?,cOli1?,cOli2?) = cOlddd(cOlp1,cOlp2)*cOlf1(cOlp2,cOli1,cOli2);
			id	cOlf1(cOlp1?,cOli1?,cOli2?) = cOlx2*cOlf(cOlp1,cOli1,cOli2);
			id	cOlddd(cOlp1?,cOlp2?)*cOlx1^cOly1?*cOlx2^cOly2? = cOldd(cOlp1,cOlp2,cOly1,cOly2);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = theta_(cOlx1-cOlx2-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx1+cOlx2)
				+theta_(cOlx2-cOlx1)*cOldd(cOlp2,cOlp1,cOlx2,cOlx1+cOlx2);
		repeat;
			id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?)*cOldd(cOlp3?,cOlp4?,cOlx3?,cOlx4?) =
				+theta_(cOlx1-cOlx3-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)
				+theta_(cOlx3-cOlx1-1)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4)
				+delta_(cOlx1-cOlx3)*theta_(cOlx2-cOlx4-1)*cOldd(cOlp1,cOlp2,cOlx1,cOlx2)
				+delta_(cOlx1-cOlx3)*theta_(cOlx4-cOlx2)*cOldd(cOlp3,cOlp4,cOlx3,cOlx4);
		endrepeat;
		id	cOldd(cOlp1?,cOlp2?,cOlx1?,cOlx2?) = cOldd(cOlp1,cOlp2);
	endif;
	repeat;
		id	cOldd(cOlp1?,cOlp2?)*cOlp1?.cOlp3? = cOldd(cOlp1,cOlp2)*cOldA1(cOlp3);
		id	cOldd(cOlp1?,cOlp2?)*cOlf(cOlp1?,cOli1?,cOli2?) = cOldd(cOlp1,cOlp2)*cOldA1(cOlk)*cOlf(cOlk,cOli1,cOli2);
		sum cOlk;
	endrepeat;
	repeat id cOldA1(?a)*cOldA1(?b) = cOldA1(?a,?b);
	id	cOldA1(?a) = cOlda1(?a);
	id	cOlda1(cOli1?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) = 0;
	id	cOlda1(cOli1?,cOli2?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2);
	id	cOlda1(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?)*cOlf(cOli1?,cOlp2?,cOlj1?)*cOldd(cOlp1?,cOlp2?) =
		-cOlda1(cOli1,cOlp2,cOli3,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli2,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOlp2,cOli4,cOli5,cOli6)*cOlf(cOli1,cOli3,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOlp2,cOli5,cOli6)*cOlf(cOli1,cOli4,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOlp2,cOli6)*cOlf(cOli1,cOli5,cOlj1)*cOldd(cOlp1,cOlp2)
		-cOlda1(cOli1,cOli2,cOli3,cOli4,cOli5,cOlp2)*cOlf(cOli1,cOli6,cOlj1)*cOldd(cOlp1,cOlp2);
	Multiply replace_(cOlda1,cOldA1);
	repeat id cOldA1(cOli1?,cOli2?,?a)*cOldd(cOlp1?,cOlp2?) = cOlp1(cOli1)*cOldA1(cOli2,?a)*cOldd(cOlp1,cOlp2);
	id	cOldA1(cOli1?)*cOldd(cOlp1?,cOlp2?) = cOlp1(cOli1)*cOldd(cOlp1,cOlp2);
	id	cOldd(cOlp1?,cOlp2?) = 1;
endif;
#call adjoint
#call contract
#call dddff
#call d2f1
#call makeds
TryReplace,cOlpA1,cOlpA2,cOlpA2,cOlpA1;
TryReplace,cOlpA1,cOlpA3,cOlpA3,cOlpA1;
TryReplace,cOlpA1,cOlpA4,cOlpA4,cOlpA1;
TryReplace,cOlpA2,cOlpA3,cOlpA3,cOlpA2;
TryReplace,cOlpA2,cOlpA4,cOlpA4,cOlpA2;
TryReplace,cOlpA3,cOlpA4,cOlpA4,cOlpA3;
*TryReplace,cOlpR1,cOlpR2,cOlpR2,cOlpR1;
*TryReplace,cOlpR1,cOlpR3,cOlpR3,cOlpR1;
*TryReplace,cOlpR1,cOlpR4,cOlpR4,cOlpR1;
*TryReplace,cOlpR2,cOlpR3,cOlpR3,cOlpR2;
*TryReplace,cOlpR2,cOlpR4,cOlpR4,cOlpR2;
*TryReplace,cOlpR3,cOlpR4,cOlpR4,cOlpR3;
Renumber 1;
if ( count(cOlpR1,1,cOlpR2,1,cOlpA1,1,cOlpA2,1) == 16 );
id	cOlf(cOlpR1,cOlpA1,cOli1?)*cOlf(cOlpR2,cOlpA2,cOli1?)*cOlpR1.cOlpR2*cOlpR1.cOlpA2*cOlpR2.cOlpA1*cOlpA1.cOlpA2^2 =
		-cOlf(cOlpR1,cOli1,cOlpR2)*cOlf(cOlpR2,cOli1,cOlpR1)*cOlpR1.cOlpR2*cOlcA^4/72
		+cOlf(cOlpA2,cOli1,cOlpA1)*cOlf(cOli1,cOlpA2,cOlpA1)*cOlpA1.cOlpA2^2*cOld33(cOlpR1,cOlpR2)/2/cOlNA;
id	cOlf(cOlpR2,cOlpA1,cOli1?)*cOlf(cOlpA1,cOlpA2,cOli1?)*cOlpR1.cOlpR2*cOlpR1.cOlpA1*cOlpR1.cOlpA2*cOlpR2.cOlpA2*cOlpA1.cOlpA2 =
	+cOlcA^2/12*cOlf(cOlpR2,cOlpA2,cOlpR1)*cOlf(cOlpR1,cOlpA2,cOlpR2)*cOlpR1.cOlpA2*cOlpR2.cOlpA2
	-1/4/cOlNA*cOld33(cOlpR1,cOlpR2)*cOlf(cOlpA1,cOli1,cOlpA2)*cOlf(cOli1,cOlpA1,cOlpA2)*cOlpA1.cOlpA2^2
	-cOlpR1.cOlpR2*cOlpR1.cOlpA1*cOlpR1.cOlpA2*cOlpR2.cOlpA1*cOlpR2.cOlpA2*cOlpA1.cOlpA2^2*cOlcA/4;
endif;
#define redolo "0"
if ( count(cOlf,1) > 0 );
	redefine redolo "1";
endif;
#call SORT(simpli-`ireduce'-3)
#if `redolo' == 0
#define ireduce "1000"
#endif
#enddo
#endif
#endprocedure
*
#procedure dddff
*
*	Takes our one irreducible object (14 vertices) and puts it in cOldddff.
*	This puts it out of range of the other operations.
*	We apply a reduction identity when there are at least two dA in it.
*	It is symmetric in its arguments.
*
*	Made by J.Vermaseren, 24-may-1997
*
if ( count(cOlf,1) == 2 );
	if ( count(<cOlpR1,1>,...,<cOlpR`RANK',1>,<cOlpA1,1>,...,<cOlpA`RANK',1>) == 12 );
		#do ir1 = 1,`RANK'-1
		#do ir2 = `ir1'+1,`RANK'
			if ( ( match(cOlf(cOlpR`ir1',cOli1?,cOli2?)) == 2 )
			&& ( match(cOlf(cOlpR`ir2',cOli1?,cOli2?)) == 2 )
			&& ( count(cOlpR`ir1',1,cOlpR`ir2',1) == 8 ) );
				id	cOlf(cOlpR`ir1',cOlpR`ir2',cOli1?)*cOlf(cOlpR`ir1',cOlpR`ir2',cOli1?)*
						cOlpR`ir1'.cOlp?^2*cOlpR`ir2'.cOlp?^2 =
						cOldRdR(cOlpR`ir1',cOlpR`ir2',cOlp);
			elseif ( ( match(cOlf(cOlpA`ir1',cOli1?,cOli2?)) == 2 )
			&& ( match(cOlf(cOlpA`ir2',cOli1?,cOli2?)) == 2 )
			&& ( count(cOlpA`ir1',1,cOlpA`ir2',1) == 8 ) );
				id	cOlf(cOlpA`ir1',cOlpA`ir2',cOli1?)*cOlf(cOlpA`ir1',cOlpA`ir2',cOli1?)*
						cOlpA`ir1'.cOlp?^2*cOlpA`ir2'.cOlp?^2 =
						cOldRdR(cOlpA`ir1',cOlpA`ir2',cOlp);
			endif;
		#enddo
		#enddo
		#do ir1 = 1,`RANK'
		#do ir2 = 1,`RANK'
			if ( ( match(cOlf(cOlpR`ir1',cOli1?,cOli2?)) == 2 )
			&& ( match(cOlf(cOlpA`ir2',cOli1?,cOli2?)) == 2 )
			&& ( count(cOlpR`ir1',1,cOlpA`ir2',1) == 8 ) );
				id	cOlf(cOlpR`ir1',cOlpA`ir2',cOli1?)*cOlf(cOlpR`ir1',cOlpA`ir2',cOli1?)*
						cOlpR`ir1'.cOlp?^2*cOlpA`ir2'.cOlp?^2 =
						cOldRdR(cOlpR`ir1',cOlpA`ir2',cOlp);
			endif;
		#enddo
		#enddo
		#do ir = 1,`RANK'
		if ( match(cOldRdR(cOlp1?,cOlp2?,cOlpR`ir')) );
			if ( count(cOlpR`ir',1) > 1 );
				id	cOldRdR(cOlp1?,cOlp2?,cOlpR`ir') = cOlf(cOlp1,cOlp2,cOlk)*cOlf(cOlp1,cOlp2,cOlk)*
								cOlp1.cOlpR`ir'^2*cOlp2.cOlpR`ir'^2;
			else;
				id	cOldRdR(cOlp1?,cOlp2?,cOlpR`ir') = cOldddff(cOlp1,cOlp2,cOlpR`ir');
			endif;
		endif;
		if ( match(cOldRdR(cOlp1?,cOlp2?,cOlpA`ir')) );
			if ( count(cOlpA`ir',1) > 1 );
				id	cOldRdR(cOlp1?,cOlp2?,cOlpA`ir') = cOlf(cOlp1,cOlp2,cOlk)*cOlf(cOlp1,cOlp2,cOlk)*
								cOlp1.cOlpA`ir'^2*cOlp2.cOlpA`ir'^2;
			else;
				id	cOldRdR(cOlp1?,cOlp2?,cOlpA`ir') = cOldddff(cOlp1,cOlp2,cOlpA`ir');
			endif;
		endif;
		#enddo
	elseif ( count(<cOlpR1,1>,...,<cOlpR`RANK',1>,<cOlpA1,1>,...,<cOlpA`RANK',1>) == 14 );
		id cOlf(cOlpR1,cOlpA1,cOli1?)*cOlf(cOlpR2,cOlpA1,cOli1?)*cOlpR1.cOlpR2^3*cOlpR1.cOlpA1*cOlpR2.cOlpA1 =
				cOldff554(cOlpR1,cOlpR2,cOlpA1);
	endif;
endif;
symmetrize cOldddff;
 
id	cOldddff(cOlp1?cOlpAs,cOlp2?cOlpAs,cOlp3?cOlpAs) =
			-2/27*cOlcA^3*cOld44(cOlp1,cOlp2)+19/15*cOlcA*cOld444(cOlp1,cOlp2,cOlp3)-8/9*cOld644(cOlp1,cOlp2,cOlp3);
id	cOldddff(cOlp1?,cOlp2?cOlpAs,cOlp3?cOlpAs) =
			-2/27*cOlcA^3*cOld44(cOlp1,cOlp2)+19/15*cOlcA*cOld444(cOlp1,cOlp2,cOlp3)-8/9*cOld644(cOlp2,cOlp1,cOlp3);

#endprocedure
*
#procedure d2f1
*
*	Routine implements two relations.
*	1: Triangles of two cOldR and one cOlf for which one of the cOldR has only
*	   one external leg.
*	2: Pairs of cOldR with each one external leg.
*	With the new version of simpli.prc this routine is still used, but
*	in principle simpli could have done without. It does make convergence
*	a little bit faster.
*
*	Completed 24-may-1997, J.Vermaseren
*
#do ir1 = 1,`RANK'-1
  if ( match(cOlf(cOlpR`ir1',cOli1?,cOli2?)) );
#do ir2 = `ir1'+1,`RANK'
	if ( count(cOlpR`ir1',1) && count(cOlpR`ir2',1) );
		id	cOlpR`ir1' = cOlx1*cOlpR`ir1';
		id	cOlpR`ir2' = cOlx2*cOlpR`ir2';
		id	cOlf(cOlpR`ir1',cOlpR`ir2',cOli1?) = cOlf(cOlpR`ir1',cOlpR`ir2',cOli1)*cOlx3/cOlx1/cOlx2;
		id	cOlpR`ir1'.cOlpR`ir2' = cOlpR`ir1'.cOlpR`ir2'/cOlx1/cOlx2;
		if ( count(cOlx3,1) == 1 );
			if ( count(cOlx1,1) == 1 );
				id	cOlf(cOlpR`ir1',cOlpR`ir2',cOli1?)*cOlpR`ir1'.cOlpR`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpR`ir1' = cOldR`ir1'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldR`ir1'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpR`ir1',cOli2,cOli1)*cOlpR`ir1'.cOlpR`ir2'^cOlx*cOlpR`ir1'.cOlpR`ir2';
			elseif ( count(cOlx2,1) == 1 );
				id	cOlf(cOlpR`ir2',cOlpR`ir1',cOli1?)*cOlpR`ir1'.cOlpR`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpR`ir2' = cOldR`ir2'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldR`ir2'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpR`ir2',cOli2,cOli1)*cOlpR`ir1'.cOlpR`ir2'^cOlx*cOlpR`ir1'.cOlpR`ir2';
			endif;
		endif;
		id	cOlx3 = 1;
	endif;
	id	cOlx1 = 1;
	id	cOlx2 = 1;
#enddo
  endif;
#enddo
#do ir1 = 1,`RANK'-1
  if ( match(cOlf(cOlpA`ir1',cOli1?,cOli2?)) );
#do ir2 = `ir1'+1,`RANK'
	if ( count(cOlpA`ir1',1) && count(cOlpA`ir2',1) );
		id	cOlpA`ir1' = cOlx1*cOlpA`ir1';
		id	cOlpA`ir2' = cOlx2*cOlpA`ir2';
		id	cOlf(cOlpA`ir1',cOlpA`ir2',cOli1?) = cOlf(cOlpA`ir1',cOlpA`ir2',cOli1)*cOlx3/cOlx1/cOlx2;
		id	cOlpA`ir1'.cOlpA`ir2' = cOlpA`ir1'.cOlpA`ir2'/cOlx1/cOlx2;
		if ( count(cOlx3,1) == 1 );
			if ( count(cOlx1,1) == 1 );
				id	cOlf(cOlpA`ir1',cOlpA`ir2',cOli1?)*cOlpA`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpA`ir1' = cOldA`ir1'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldA`ir1'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpA`ir1',cOli2,cOli1)*cOlpA`ir1'.cOlpA`ir2'^cOlx*cOlpA`ir1'.cOlpA`ir2';
			elseif ( count(cOlx2,1) == 1 );
				id	cOlf(cOlpA`ir2',cOlpA`ir1',cOli1?)*cOlpA`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpA`ir2' = cOldA`ir2'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldA`ir2'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpA`ir2',cOli2,cOli1)*cOlpA`ir1'.cOlpA`ir2'^cOlx*cOlpA`ir1'.cOlpA`ir2';
			endif;
		endif;
		id	cOlx3 = 1;
	endif;
	id	cOlx1 = 1;
	id	cOlx2 = 1;
#enddo
  endif;
#enddo
#do ir1 = 1,`RANK'
  if ( match(cOlf(cOlpR`ir1',cOli1?,cOli2?)) );
#do ir2 = 1,`RANK'
	if ( count(cOlpR`ir1',1) && count(cOlpA`ir2',1) );
		id	cOlpR`ir1' = cOlx1*cOlpR`ir1';
		id	cOlpA`ir2' = cOlx2*cOlpA`ir2';
		id	cOlf(cOlpR`ir1',cOlpA`ir2',cOli1?) = cOlf(cOlpR`ir1',cOlpA`ir2',cOli1)*cOlx3/cOlx1/cOlx2;
		id	cOlpR`ir1'.cOlpA`ir2' = cOlpR`ir1'.cOlpA`ir2'/cOlx1/cOlx2;
		if ( count(cOlx3,1) == 1 );
			if ( count(cOlx1,1) == 1 );
				id	cOlf(cOlpR`ir1',cOlpA`ir2',cOli1?)*cOlpR`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpR`ir1' = cOldR`ir1'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldR`ir1'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpR`ir1',cOli2,cOli1)*cOlpR`ir1'.cOlpA`ir2'^cOlx*cOlpR`ir1'.cOlpA`ir2';
			elseif ( count(cOlx2,1) == 1 );
				id	cOlf(cOlpA`ir2',cOlpR`ir1',cOli1?)*cOlpR`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx,cOli1);
				id	cOlpA`ir2' = cOldA`ir2'(?);
				id	cOlorig(cOlx?,cOli1?)*cOldA`ir2'(cOli2?) = -1/(cOlx+1)*
						cOlf(cOlpA`ir2',cOli2,cOli1)*cOlpR`ir1'.cOlpA`ir2'^cOlx*cOlpR`ir1'.cOlpA`ir2';
			endif;
		endif;
		id	cOlx3 = 1;
	endif;
	id	cOlx1 = 1;
	id	cOlx2 = 1;
#enddo
  endif;
#enddo

Multiply cOly;
while ( count(cOly,1) );
  id cOly = 1;
  #do ir1 = 1,`RANK'-1
  #do ir2 = `ir1'+1,`RANK'
	if ( count(cOlpR`ir1',1) && count(cOlpR`ir2',1) );
		id	cOlpR`ir1'.cOlpR`ir2'^cOlx? = cOlorig(cOlx);
		if ( ( count(cOlpR`ir1',1) == 1 ) && ( count(cOlpR`ir2',1) == 1 ) );
			id	cOlpR`ir1' = cOldR`ir1'(?);
			id	cOlpR`ir2' = cOldR`ir2'(?);
			id	cOlorig(cOlx?)*cOldR`ir1'(cOli1?)*cOldR`ir2'(cOli2?) =
						cOly*d_(cOli1,cOli2)/cOlNA*cOlpR`ir1'.cOlpR`ir2'^cOlx*cOlpR`ir1'.cOlpR`ir2';
		else;	
			id	cOlorig(cOlx?) = cOlpR`ir1'.cOlpR`ir2'^cOlx;
		endif;
	endif;
  #enddo
  #enddo

  #do ir1 = 1,`RANK'-1
  #do ir2 = `ir1'+1,`RANK'
	if ( count(cOlpA`ir1',1) && count(cOlpA`ir2',1) );
		id	cOlpA`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx);
		if ( ( count(cOlpA`ir1',1) == 1 ) && ( count(cOlpA`ir2',1) == 1 ) );
			id	cOlpA`ir1' = cOldA`ir1'(?);
			id	cOlpA`ir2' = cOldA`ir2'(?);
			id	cOlorig(cOlx?)*cOldA`ir1'(cOli1?)*cOldA`ir2'(cOli2?) =
						cOly*d_(cOli1,cOli2)/cOlNA*cOlpA`ir1'.cOlpA`ir2'^cOlx*cOlpA`ir1'.cOlpA`ir2';
		else;	
			id	cOlorig(cOlx?) = cOlpA`ir1'.cOlpA`ir2'^cOlx;
		endif;
	endif;
  #enddo
  #enddo

  #do ir1 = 1,`RANK'
  #do ir2 = 1,`RANK'
	if ( count(cOlpR`ir1',1) && count(cOlpA`ir2',1) );
		id	cOlpR`ir1'.cOlpA`ir2'^cOlx? = cOlorig(cOlx);
		if ( ( count(cOlpR`ir1',1) == 1 ) && ( count(cOlpA`ir2',1) == 1 ) );
			id	cOlpR`ir1' = cOldR`ir1'(?);
			id	cOlpA`ir2' = cOldA`ir2'(?);
			id	cOlorig(cOlx?)*cOldR`ir1'(cOli1?)*cOldA`ir2'(cOli2?) =
						cOly*d_(cOli1,cOli2)/cOlNA*cOlpR`ir1'.cOlpA`ir2'^cOlx*cOlpR`ir1'.cOlpA`ir2';
		else;	
			id	cOlorig(cOlx?) = cOlpR`ir1'.cOlpA`ir2'^cOlx;
		endif;
	endif;
  #enddo
  #enddo
endwhile;
*
#endprocedure
*
#procedure makeds
*
*	Tries to rewrite completed results in terms of d functions.
*	This is not as easy as one might think because there are many
*	potential topologies and we would like to use a minimum number
*	of statements. It has become much simpler after symmetric functions
*	started to work.
*	Routine completed 24-may-1997 by J.Vermaseren
*
#do isim1 = 1,`RANK'
#do isim2 = 1,`RANK'
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpA`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpA`isim2') == 2 ) )
		id	cOlpR`isim1'.cOlpA`isim2'^2 = cOlcA^2/6*replace_(cOlpA`isim2',cOlpR`isim1');
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpR`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 3 ) ) discard;
	if ( ( count(cOlpR`isim1',1) == 4 ) && ( count(cOlpR`isim2',1) == 5 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 4 ) ) discard;
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpA`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 3 ) ) discard;
	if ( ( count(cOlpA`isim1',1) == 4 ) && ( count(cOlpR`isim2',1) == 5 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 4 ) ) discard;
#enddo
#enddo

if ( ( count(cOlf,1) == 0 )
		&& ( count(<cOlpR1,1,cOlpA1,1>,...,<cOlpR`RANK',1,cOlpA`RANK',1>) ) );
  #do ir = 1,`RANK'
    id cOlpR`ir' = cOlx*cOlpR`ir';
    id cOlpA`ir' = cOlx*cOlpA`ir';
  #enddo
  #do ir = 1,`RANK'
    totensor,cOlpR`ir',cOldr`ir';
  #enddo
  #do ir = 1,`RANK'
    totensor,cOlpA`ir',cOlda`ir';
  #enddo
  renumber;
  repeat;
	id cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli3?)*cOldr2?cOldar[cOlx4](cOli1?,cOli2?,cOli4?) =
			cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4])*cOlx1*d_(cOli3,cOli4)/cOlNA;
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli3?,cOli5?) =
			cOld44(cOlpAR[cOlx3],cOlpAR[cOlx4])*cOlx1*d_(cOli4,cOli5)/cOlNA;
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli5?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli4?,cOli6?) =
			cOld55(cOlpAR[cOlx3],cOlpAR[cOlx4])*cOlx1*d_(cOli5,cOli6)/cOlNA;
  endrepeat;
  if ( count(cOlx1,1) );
    id cOlx = 1;
    id cOlx1 = 1;
    #do ir = 1,`RANK'
      tovector,cOlpR`ir',cOldr`ir';
    #enddo
    #do ir = 1,`RANK'
      tovector,cOlpA`ir',cOlda`ir';
    #enddo
    #do ir = 1,`RANK'
      id cOlpR`ir' = cOlx*cOlpR`ir';
      id cOlpA`ir' = cOlx*cOlpA`ir';
    #enddo
    #do ir = 1,`RANK'
      totensor,cOlpR`ir',cOldr`ir';
    #enddo
    #do ir = 1,`RANK'
      totensor,cOlpA`ir',cOlda`ir';
    #enddo
    renumber;
  endif;
  id cOldr1?cOldar(cOli1?,cOli2?,cOli3?)*cOlda1?cOldar(cOli1?,cOli2?,cOli3?,cOli4?) = 0;
  id cOldr1?cOldar(cOli1?,cOli2?,cOli3?,cOli4?)*cOlda1?cOldar(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?) = 0;
  if ( count(cOlx,1) == 6 );
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli3?) = cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4]);
    symmetrize cOld33;
  elseif ( count(cOlx,1) == 8 );
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli4?) = cOld44(cOlpAR[cOlx3],cOlpAR[cOlx4]);
    symmetrize cOld44;
  elseif ( count(cOlx,1) == 10 );
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli5?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli5?) = cOld55(cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli5?)*cOldr2?cOldar[cOlx4](cOli3?,...,cOli5?) = cOld433(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
    symmetrize cOld55;
    symmetrize cOld433,2,3;
  elseif ( count(cOlx,1) == 12 );
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli6?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli6?) = cOld66(cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli5?,cOli6?)*cOldr2?cOldar[cOlx4](cOli3?,...,cOli6?)
				 = cOld444(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?)*cOldr2?cOldar[cOlx4](cOli4?,...,cOli6?) = cOld633(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli3?)*cOldr2?cOldar[cOlx4](cOli1?,cOli4?,cOli5?)*cOlda1?cOldar[cOlx1](cOli2?,cOli4?,cOli6?)
			*cOlda2?cOldar[cOlx2](cOli3?,cOli5?,cOli6?) = cOld3333(cOlpAR[cOlx3],cOlpAR[cOlx4],cOlpAR[cOlx1],cOlpAR[cOlx2]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?,cOli6?)*cOldr2?cOldar[cOlx4](cOli4?,...,cOli6?) = cOld543(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id,many,cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli4?) =
			cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4])*d_(cOli3,cOli4)/cOlNA;
    symmetrize cOld33;
    symmetrize cOld66;
    symmetrize cOld444;
    symmetrize cOld633,2,3;
  elseif ( count(cOlx,1) == 14 );
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli7?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli7?) = cOld77(cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli3?)*cOldr2?cOldar[cOlx4](cOli1?,cOli2?,cOli4?) =
			cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4])*d_(cOli3,cOli4)/cOlNA;
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli3?,cOli5?) =
			cOld44(cOlpAR[cOlx3],cOlpAR[cOlx4])*d_(cOli4,cOli5)/cOlNA;
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli7?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?)*cOldr2?cOldar[cOlx4](cOli5?,...,cOli7?)
				 = cOld743(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?,cOli7?)*cOldr2?cOldar[cOlx4](cOli4?,...,cOli7?)
				 = cOld644(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?,cOli6?,cOli7?)*cOldr2?cOldar[cOlx4](cOli4?,...,cOli7?)
				 = cOld554(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?,cOli7?)*cOldr2?cOldar[cOlx4](cOli5?,...,cOli7?)
				 = cOld653(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOldr1?cOldar[cOlx3](cOli1?,cOli2?,cOli6?)*cOldr2?cOldar[cOlx4](cOli3?,cOli4?,cOli7?)
			*cOlda2?cOldar[cOlx2](cOli6?,cOli6?,cOli7?) = cOld5333(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4],cOlpAR[cOlx2]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli5?,...,cOli7?)*cOldr1?cOldar[cOlx3](cOli2?,cOli3?,cOli5?)
			*cOldr2?cOldar[cOlx4](cOli4?,cOli6?,cOli7?) = cOld4433a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli5?,cOli6?)*cOldr1?cOldar[cOlx3](cOli3?,cOli5?,cOli7?)
			*cOldr2?cOldar[cOlx4](cOli4?,cOli6?,cOli7?) = cOld4433b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli5?,cOli6?)*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli7?)
			*cOldr2?cOldar[cOlx4](cOli5?,cOli6?,cOli7?) = cOld4433c(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
    symmetrize cOld33;
    symmetrize cOld44;
    symmetrize cOld77;
    symmetrize cOld644,2,3;
    symmetrize cOld554,1,2;
	symmetrize cOld5333,2,3;
  elseif ( count(cOlx,1) == 16 );
*
*   There are actually 23 topologies that need to be defined here.
*	We have here at least the set needed for the adjoint (5 topologies).
*	At least 5 of the 23 can be reduced later.
*
	id cOldr1?cOldar[cOlx3](cOli1?,...,cOli8?)*cOldr2?cOldar[cOlx4](cOli1?,...,cOli8?) = cOld88(cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli8?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?)*cOldr2?cOldar[cOlx4](cOli5?,...,cOli8?)
				 = cOld844(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli8?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli5?)*cOldr2?cOldar[cOlx4](cOli6?,...,cOli8?)
				 = cOld853(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli7?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli5?,cOli8?)*cOldr2?cOldar[cOlx4](cOli6?,...,cOli8?)
				 = cOld763(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli7?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?,cOli8?)*cOldr2?cOldar[cOlx4](cOli5?,...,cOli8?)
				 = cOld754(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli7?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?)*cOldr1?cOldar[cOlx3](cOli4?,cOli5?,cOli8?)
			*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?) = cOld7333(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli4?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli5?,...,cOli8?)
				 = cOld664(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOldr1?cOldar[cOlx3](cOli1?,...,cOli3?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli4?,...,cOli8?)
				 = cOld655(cOlpAR[cOlx1],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli7?,cOli8?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli5?)*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?)
				 = cOld6433a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli7?,cOli8?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli7?)*cOldr2?cOldar[cOlx4](cOli5?,cOli6?,cOli8?)
				 = cOld6433b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli6?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?,cOli7?)
		*cOldr1?cOldar[cOlx3](cOli4?,cOli5?,cOli8?)*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?)
				 = cOld6433c(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli6?,cOli7?,cOli8?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli6?)*cOldr2?cOldar[cOlx4](cOli5?,cOli6?,cOli8?)
				 = cOld5533a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli6?,cOli7?,cOli8?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli5?)*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?)
				 = cOld5533b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?,cOli6?,cOli7?)
		*cOldr1?cOldar[cOlx3](cOli4?,cOli6?,cOli8?)*cOldr2?cOldar[cOlx4](cOli5?,cOli7?,cOli8?)
				 = cOld5533c(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?,cOli6?,cOli7?)
		*cOldr1?cOldar[cOlx3](cOli4?,cOli5?,cOli8?)*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?)
				 = cOld5533d(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli6?,cOli7?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli6?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli4?,cOli5?,cOli8?)
				 = cOld5443a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?,cOli6?)
		*cOldr1?cOldar[cOlx3](cOli4?,cOli6?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli5?,cOli7?,cOli8?)
				 = cOld5443b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli6?,cOli7?)
		*cOldr1?cOldar[cOlx3](cOli3?,cOli4?,cOli6?,cOli8?)*cOldr2?cOldar[cOlx4](cOli5?,cOli7?,cOli8?)
				 = cOld5443c(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli5?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli3?,cOli6?)
		*cOldr1?cOldar[cOlx3](cOli4?,cOli5?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli6?,cOli7?,cOli8?)
				 = cOld5443d(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli5?,cOli6?)*cOldr1?cOldar[cOlx3](cOli5?,...,cOli8?)
			*cOldr2?cOldar[cOlx4](cOli3?,cOli4?,cOli7?,cOli8?) = cOld4444a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli5?,cOli6?)*cOldr1?cOldar[cOlx3](cOli3?,cOli5?,cOli7?,cOli8?)
			*cOldr2?cOldar[cOlx4](cOli4?,cOli6?,cOli7?,cOli8?) = cOld4444b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli5?,cOli6?)
			*cOldr1?cOldar[cOlx3](cOli2?,cOli5?,cOli7?)*cOldr2?cOldar[cOlx4](cOli3?,cOli6?,cOli8?)
			*cOldr3?cOldar[cOlx5](cOli4?,cOli7?,cOli8?) = cOld43333a(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4],cOlpAR[cOlx5]);
	id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli1?,cOli2?,cOli5?)
			*cOldr1?cOldar[cOlx3](cOli3?,cOli6?,cOli7?)*cOldr2?cOldar[cOlx4](cOli4?,cOli6?,cOli8?)
			*cOldr3?cOldar[cOlx5](cOli5?,cOli7?,cOli8?) = cOld43333b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4],cOlpAR[cOlx5]);
    symmetrize cOld33;
    symmetrize cOld44;
    symmetrize cOld55;
    symmetrize cOld88;
    symmetrize cOld844,2,3;
    symmetrize cOld664,1,2;
    rcyclesymmetrize cOld4444a;
	symmetrize cOld4444b,1,2;
	symmetrize cOld4444b,3,4;
  else;
*   We don't know yet what to do.
  endif;
  id cOlx^cOly? = 1;
*
*   Some dependencies
*
  id cOld5443b(cOlp1?,cOlp2?,cOlp3?cOlpAs,cOlp4?) = cOld543(cOlp1,cOlp2,cOlp4);
  id cOld5443d(cOlp1?,cOlp2?,cOlp3?cOlpAs,cOlp4?) = cOld543(cOlp1,cOlp2,cOlp4);
  id cOld6433a(cOlp1?,cOlp2?cOlpAs,cOlp3?,cOlp4?) = cOld633(cOlp1,cOlp3,cOlp4);
  id cOld43333b(cOlp1?cOlpAs,cOlp2?,cOlp3?,cOlp4?,cOlp5?) = cOlcA^2/6*cOld3333(cOlp2,cOlp3,cOlp4,cOlp5);
  id cOld6433a(cOlp1?cOlpRs,cOlp2?,cOlp3?,cOlp4?) = -1/8*cOlcA*cOld4433c(cOlp1,cOlp2,cOlp3,cOlp4)
		-1/4*cOlcA*cOld4433a(cOlp1,cOlp2,cOlp3,cOlp4)-1/4*cOlI2R*cOlcA^2*cOld433(cOlp2,cOlp3,cOlp4)
		+1/cOlNR*cOld33(cOlp1,cOlp3)*cOld433(cOlp2,cOlp1,cOlp4);
  id cOld6433a(cOlp1?cOlpAs,cOlp2?,cOlp3?,cOlp4?) = -1/8*cOlcA*cOld4433c(cOlp1,cOlp2,cOlp3,cOlp4)
		-1/4*cOlcA*cOld4433a(cOlp1,cOlp2,cOlp3,cOlp4)-1/4*cOlcA^3*cOld433(cOlp2,cOlp3,cOlp4);
  id cOld5533b(cOlp1?,cOlp2?,cOlp3?,cOlp4?) = cOld33(cOlp1,cOlp3)*cOld33(cOlp2,cOlp4)/cOlNA*(cOlcR-cOlcA/4)^2;
  id cOld633(cOlp1?cOlpRs,cOlp2?,cOlp3?) = -3/8*cOlcA*cOld433(cOlp1,cOlp2,cOlp3)
			-1/40*cOlI2R*cOlcA^2*cOld33(cOlp2,cOlp3)+cOld33(cOlp1,cOlp2)*cOld33(cOlpR4,cOlp3)/cOlNR;
  id cOld633(cOlp1?cOlpAs,cOlp2?,cOlp3?) = -3/8*cOlcA*cOld433(cOlp1,cOlp2,cOlp3)-1/40*cOlcA^3*cOld33(cOlp2,cOlp3);
  id cOld743(cOlp1?cOlpRs,cOlp2?,cOlp3?) = -1/2*cOlcA*cOld543(cOlp1,cOlp2,cOlp3)
		+1/cOlNR*cOld33(cOlpR4,cOlp3)*cOld44(cOlp1,cOlp2)-43/120/cOlNA*cOld33(cOlp1,cOlp3)*cOld44(cOlpA4,cOlp2)
		-23/1440*cOlcA^2*cOld433(cOlp2,cOlp1,cOlp3)+49/60*cOld4433b(cOlpA4,cOlp2,cOlp1,cOlp3);
  id cOld4433a(cOlp1?cOlpAs,cOlp2?,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp2,cOlp3,cOlp4);
  id cOld4433a(cOlp1?,cOlp2?cOlpAs,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp1,cOlp3,cOlp4);
  id cOld4433c(cOlp1?cOlpAs,cOlp2?,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp2,cOlp3,cOlp4);
  id cOld4433c(cOlp1?,cOlp2?cOlpAs,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp1,cOlp3,cOlp4);
  id cOld433(cOlp1?cOlpAs,cOlp2?,cOlp3?) = 1/6*cOlcA^2*cOld33(cOlp2,cOlp3);
  id cOld66(cOlpA1,cOlpA2) = 5/8*cOld444(cOlpA1,cOlpA2,cOlpA3)-7/240*cOlcA^2*cOld44(cOlpA1,cOlpA2)
			-1/864*cOlcA^6*cOlNA;
  id cOld4433b(cOlpA1,cOlpA2,cOlpR2,cOlpR1) = cOld4433b(cOlpA1,cOlpA2,cOlpR1,cOlpR2);
  id cOld4433b(cOlpA2,cOlpA1,cOlpR2,cOlpR1) = cOld4433b(cOlpA1,cOlpA2,cOlpR1,cOlpR2);
  #do ir = 1,`RANK'
    tovector,cOlpR`ir',cOldr`ir';
  #enddo
  #do ir = 1,`RANK'
    tovector,cOlpA`ir',cOlda`ir';
  #enddo
else if ( ( count(cOlf,1) == 2 ) && (
	count(<cOlpR1,1>,...,<cOlpR`RANK',1>,<cOlpA1,1>,...,<cOlpA`RANK',1>) == 14 ) );
*
*	We have here a few terms that manage to construct a holding pattern.
*
  #do ir = 1,`RANK'
    totensor,cOlpR`ir',cOldr`ir';
  #enddo
  #do ir = 1,`RANK'
    totensor,cOlpA`ir',cOlda`ir';
  #enddo
  renumber;
  id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli3?,cOli5?,cOli6?,cOli7?)*
	cOldr1?cOldar[cOlx3](cOli4?,cOli6?,cOli8?)*cOldr2?cOldar[cOlx4](cOli7?,cOli8?,cOli9?)*cOlf(cOli1?,cOli5?,cOli10?)*cOlf(cOli2?,cOli9?,cOli10?) =
			+cOlcA/4*cOld4433b(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx3],cOlpAR[cOlx4])
		+cOlda1(cOli1,cOli2,cOli3,cOli5)*cOlda2(cOli3,cOli5,cOli6,cOli7)*cOldr1(cOli4,cOli1,cOli8)*cOldr2(cOli7,cOli8,cOli9)
			*cOlf(cOli6,cOli4,cOli10)*cOlf(cOli2,cOli9,cOli10);
  id cOlda1?cOldar[cOlx1](cOli1?,...,cOli4?)*cOlda2?cOldar[cOlx2](cOli2?,cOli3?,cOli5?,cOli6?)*
	cOldr1?cOldar[cOlx3](cOli6?,cOli7?,cOli8?)*cOldr2?cOldar[cOlx4](cOli4?,cOli7?,cOli9?)*cOlf(cOli1?,cOli8?,cOli10?)*cOlf(cOli5?,cOli9?,cOli10?) =
			+cOlcA/4*cOld4433c(cOlpAR[cOlx1],cOlpAR[cOlx2],cOlpAR[cOlx4],cOlpAR[cOlx3])
			-cOlcA/6/cOlNA*cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4])*cOld44(cOlpAR[cOlx1],cOlpAR[cOlx2]);
  id cOld4433c(cOlp1?cOlpAs,cOlp2?,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp2,cOlp3,cOlp4);
  id cOld4433c(cOlp1?,cOlp2?cOlpAs,cOlp3?,cOlp4?) = 1/6*cOlcA^2*cOld433(cOlp1,cOlp3,cOlp4);
  id cOld433(cOlp1?cOlpAs,cOlp2?,cOlp3?) = 1/6*cOlcA^2*cOld33(cOlp2,cOlp3);
  #do ir = 1,`RANK'
    tovector,cOlpR`ir',cOldr`ir';
  #enddo
  #do ir = 1,`RANK'
    tovector,cOlpA`ir',cOlda`ir';
  #enddo
  Symmetrize,cOld33;
  Symmetrize,cOld44;
  Symmetrize cOld4444b,1,2;
  Symmetrize cOld4444b,3,4;
  id cOld4433b(cOlpA1,cOlpA2,cOlpR2,cOlpR1) = cOld4433b(cOlpA1,cOlpA2,cOlpR1,cOlpR2);
  id cOld4433b(cOlpA2,cOlpA1,cOlpR2,cOlpR1) = cOld4433b(cOlpA1,cOlpA2,cOlpR1,cOlpR2);
else if ( ( count(cOlf,1) == 2 ) && (
	count(<cOlpR1,1>,...,<cOlpR`RANK',1>,<cOlpA1,1>,...,<cOlpA`RANK',1>) == 12 ) );
*
*	We have here a few terms that manage to construct a holding pattern.
*
  #do ir = 1,`RANK'
    totensor,cOlpR`ir',cOldr`ir';
  #enddo
  renumber;
  id cOlda1?cOldar[cOlx1](cOli1?,cOli2?,cOli3?)*cOlda2?cOldar[cOlx2](cOli1?,cOli4?,cOli5?)*cOlf(cOli3?,cOli8?,cOli9?)*
	cOldr1?cOldar[cOlx3](cOli2?,cOli6?,cOli7?)*cOldr2?cOldar[cOlx4](cOli5?,cOli7?,cOli8?)*cOlf(cOli4?,cOli9?,cOli6?) =
		+cOlcA/cOlNA/4*cOld33(cOlpAR[cOlx1],cOlpAR[cOlx2])*cOld33(cOlpAR[cOlx3],cOlpAR[cOlx4])
		-cOlcA/cOlNA/4*cOld33(cOlpAR[cOlx1],cOlpAR[cOlx3])*cOld33(cOlpAR[cOlx2],cOlpAR[cOlx4])
			;
  #do ir = 1,`RANK'
    tovector,cOlpR`ir',cOldr`ir';
  #enddo
  Symmetrize,cOld3333;
  Symmetrize cOld33;
endif;
*
#endprocedure
*
#procedure contract
*
*	Remove contracted indices in the same invariant.
*	These objects are not supposed to occur very often.
*
*	Routine by J.Vermaseren, 24-may-1997
*
repeat;
#do isim = 1,`RANK'
if ( match(cOlpR`isim'.cOlpR`isim') );
	ToTensor cOlpR`isim',cOldR1;
	id	cOldR1(?a,cOli1?,?b,cOli1?,?c) = cOldR1(cOli1,cOli1,?a,?b,?c);
	id	cOldR1(cOli1?,cOli1?) = cOlNA*cOlI2R;
	id	cOldR1(cOli5?,cOli5?,cOli1?) = 0;
	id	cOldR1(cOli5?,cOli5?,cOli1?,cOli2?) = (cOlcR-cOlcA/6)*d_(cOli1,cOli2)*cOlI2R;
	id	cOldR1(cOli5?,cOli5?,cOli1?,cOli2?,cOli3?) =
			(cOlcR-cOlcA/4)*cOlpR`isim'(cOli1)*cOlpR`isim'(cOli2)*cOlpR`isim'(cOli3);
	id	cOldR1(cOli5?,cOli5?,cOli1?,cOli2?,cOli3?,cOli4?) =
			cOlpR`isim'(cOli1)*cOlpR`isim'(cOli2)*cOlpR`isim'(cOli3)*cOlpR`isim'(cOli4)*(cOlcR-cOlcA/3)
			+cOldA(cOli1,cOli2,cOli3,cOli4)*cOlI2R/30;
	id	cOldR1(cOli6?,cOli6?,cOli1?,cOli2?,cOli3?,cOli4?,cOli5?) =
			cOlpR`isim'(cOli1)*cOlpR`isim'(cOli2)*cOlpR`isim'(cOli3)*cOlpR`isim'(cOli4)*cOlpR`isim'(cOli5)
				*(cOlcR-5*cOlcA/12)+(
			+cOlpR`isim'(cOli1)*cOlpR`isim'(cOli2)*cOldA(cOlpR`isim',cOli3,cOli4,cOli5)
			+cOlpR`isim'(cOli1)*cOlpR`isim'(cOli3)*cOldA(cOlpR`isim',cOli2,cOli4,cOli5)
			+cOlpR`isim'(cOli1)*cOlpR`isim'(cOli4)*cOldA(cOlpR`isim',cOli2,cOli3,cOli5)
			+cOlpR`isim'(cOli1)*cOlpR`isim'(cOli5)*cOldA(cOlpR`isim',cOli2,cOli3,cOli4)
			+cOlpR`isim'(cOli2)*cOlpR`isim'(cOli3)*cOldA(cOlpR`isim',cOli1,cOli4,cOli5)
			+cOlpR`isim'(cOli2)*cOlpR`isim'(cOli4)*cOldA(cOlpR`isim',cOli1,cOli3,cOli5)
			+cOlpR`isim'(cOli2)*cOlpR`isim'(cOli5)*cOldA(cOlpR`isim',cOli1,cOli3,cOli4)
			+cOlpR`isim'(cOli3)*cOlpR`isim'(cOli4)*cOldA(cOlpR`isim',cOli1,cOli2,cOli5)
			+cOlpR`isim'(cOli3)*cOlpR`isim'(cOli5)*cOldA(cOlpR`isim',cOli1,cOli2,cOli4)
			+cOlpR`isim'(cOli4)*cOlpR`isim'(cOli5)*cOldA(cOlpR`isim',cOli1,cOli2,cOli3)
			)/10*cOlI2R/12;
	id	cOldR1(cOli7?,cOli7?,cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?) =
			cOlpR`isim'(cOli1)*cOlpR`isim'(cOli2)*cOlpR`isim'(cOli3)*cOlpR`isim'(cOli4)*cOlpR`isim'(cOli5)
				*cOlpR`isim'(cOli6)*(cOlcR-cOlcA/2)
			+1/6*cOldA(cOlpR`isim',cOlpR`isim',cOlpR`isim',cOlpR`isim')*
				dd_(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)/15/cOlNA^3
			-1/42*cOlI2R*cOldA(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6);
	if ( count(cOldA,1) == 0 );
#do isimpli = 1,`RANK'
	elseif ( count(cOlpA`isimpli',1) == 0 );
		id,once,cOldA(?a) = cOldA`isimpli'(?a);
		ToVector,cOldA`isimpli',cOlpA`isimpli';
#enddo
	endif;
endif;
#enddo
#do isim = 1,`RANK'
if ( match(cOlpA`isim'.cOlpA`isim') );
	ToTensor cOlpA`isim',cOldA1;
	id	cOldA1(?a,cOli1?,?b,cOli1?,?c) = cOldA1(cOli1,cOli1,?a,?b,?c);
	id	cOldA1(cOli1?,cOli1?) = cOlNA*cOlcA;
	id	cOldA1(cOli5?,cOli5?,cOli1?,cOli2?) = 5/6*cOlcA^2*d_(cOli1,cOli2);
	id	cOldA1(cOli5?,cOli5?,cOli1?,cOli2?,cOli3?,cOli4?) =
			+7/10*cOlcA*cOlpA`isim'(cOli1)*cOlpA`isim'(cOli2)*cOlpA`isim'(cOli3)*cOlpA`isim'(cOli4);
	id	cOldA1(cOli7?,cOli7?,cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?) =
			+10/21*cOlcA*cOldA(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)
			+1/6*cOldA(cOlpA`isim',cOlpA`isim',cOlpA`isim',cOlpA`isim')*
				dd_(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)/15/cOlNA^3;
	if ( count(cOldA,1) == 0 );
#do isimpli = 1,`RANK'
	elseif ( count(cOlpA`isimpli',1) == 0 );
		id,once,cOldA(?a) = cOldA`isimpli'(?a);
		ToVector,cOldA`isimpli',cOlpA`isimpli';
#enddo
	endif;
endif;
#enddo
repeat;
id cOlda1?cOldas(cOli1?,cOli2?,cOli3?,cOli3?) = 5/6*cOlcA^2*d_(cOli1,cOli2);
id cOlda1?cOldas(cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli5?) = 7/10*cOlcA*cOlda1(cOli1,cOli2,cOli3,cOli4);
id cOlda1?cOldas[cOlx1](cOli1?,cOli2?,cOli3?,cOli4?,cOli5?,cOli6?,cOli7?,cOli7?) =
			+10/21*cOlcA*cOlda1(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)
			+1/6*cOld44(cOlpAs[cOlx1],cOlpA4)*dd_(cOli1,cOli2,cOli3,cOli4,cOli5,cOli6)/15/cOlNA^3;
endrepeat;

#do isim1 = 1,`RANK'
#do isim2 = 1,`RANK'
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpA`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpA`isim2') == 2 ) )
		id	cOlpR`isim1'.cOlpA`isim2'^2 = cOlcA^2/6*replace_(cOlpA`isim2',cOlpR`isim1');
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpR`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 3 ) ) discard;
	if ( ( count(cOlpR`isim1',1) == 4 ) && ( count(cOlpR`isim2',1) == 5 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 4 ) ) discard;
	if ( ( count(cOlpR`isim1',1) == 3 ) && ( count(cOlpA`isim2',1) == 4 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 3 ) ) discard;
	if ( ( count(cOlpA`isim1',1) == 4 ) && ( count(cOlpR`isim2',1) == 5 )
		&& ( match(cOlpR`isim1'.cOlpR`isim2') == 4 ) ) discard;
#enddo
#enddo
EndRepeat;
Renumber;
#endprocedure
*
#procedure docolor
#call color
#call SORT(docolor-1)
#call adjoint
#call SORT(docolor-2)
#call simpli
id	cOlacc(cOlx?) = cOlx;
#endprocedure
